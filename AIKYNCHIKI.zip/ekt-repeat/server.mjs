import http from 'node:http';
import {readFile,stat,realpath} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes,timingSafeEqual,createHash} from 'node:crypto';
import {understand,ServiceError} from './server/ai.mjs';
import {createStore} from './server/store.mjs';
import {createCartService} from './server/cart.mjs';
import {catalogSnapshot,getCatalogSchema,catalogCsv,ensureCatalog,catalogDetail} from './server/catalog.mjs';

const root=path.dirname(fileURLToPath(import.meta.url));
for(const name of ['.env.local','.env.ekt.local'])try{const text=await readFile(path.join(root,name),'utf8');for(const line of text.split(/\r?\n/)){const m=line.match(/^([A-Z_]+)=(.*)$/);if(m&&['OPENAI_API_KEY','OPENAI_MODEL','EKT_API_USERNAME','EKT_API_PASSWORD','CATALOG_SOURCE'].includes(m[1])&&!process.env[m[1]])process.env[m[1]]=m[2].trim();}}catch{}
const publicRoot=await realpath(path.join(root,'dist'));const port=Number(process.env.PORT||8080);const origin=process.env.PUBLIC_ORIGIN||`http://127.0.0.1:${port}`;
const publicUrl=new URL(origin);if(publicUrl.origin!==origin||!['http:','https:'].includes(publicUrl.protocol)||publicUrl.username||publicUrl.password)throw Error('Invalid PUBLIC_ORIGIN');
const basePath=process.env.BASE_PATH||'/';if(!/^\/(?:[a-zA-Z0-9_-]+\/)*$/.test(basePath))throw Error('Invalid BASE_PATH');
const allowedFrames=(process.env.EMBED_ORIGINS||'').split(',').filter(Boolean).map(s=>{const u=new URL(s.trim());if(u.origin!==s.trim()||u.protocol!=='https:')throw Error('Invalid EMBED_ORIGINS');return u.origin;});
const csp="default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self' blob:; worker-src 'self' blob:; frame-src 'self'; frame-ancestors 'self' "+allowedFrames.join(' ')+"; object-src 'none'; base-uri 'self'; form-action 'self'";
const token=randomBytes(32).toString('hex');let active=0,requests=[];
const store=createStore(process.env.EKT_DATA_DIR||path.join(root,'.data'));
const carts=createCartService(store.db);
const digest=value=>createHash('sha256').update(value).digest('hex');
const cookie=(req,name)=>(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='))?.slice(name.length+1)||'';
const addCookie=(res,name,value,maxAge)=>{const existing=res.getHeader('Set-Cookie')||[];res.setHeader('Set-Cookie',[...(Array.isArray(existing)?existing:[existing]),`${name}=${value}; Path=${basePath}; HttpOnly; SameSite=Strict; Max-Age=${maxAge}${publicUrl.protocol==='https:'?'; Secure':''}`]);};
function cartIdentity(req,res){const user=store.user(cookieToken(req));if(req.headers['x-ekt-user']!==(user?.id||'guest'))throw new ServiceError('login_required',401);if(user)return {owner:'u:'+user.id,actor:digest(cookieToken(req))};let token=cookie(req,'ekt_cart');if(!/^[a-f0-9]{64}$/.test(token)){token=randomBytes(32).toString('hex');addCookie(res,'ekt_cart',token,86400);}return {owner:'g:'+digest(token),actor:digest(token)};}
const authRequests=[];const ticketRequests=[];
const cookieToken=req=>(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('ekt_session='))?.slice(12)||'';
const setSession=(res,value)=>addCookie(res,'ekt_session',value,value?604800:0);
async function body(req){let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>1000000)throw new ServiceError('too_large',413);chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw new ServiceError('invalid_json',400);}}
const types={'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.wasm':'application/wasm','.gz':'application/gzip','.svg':'image/svg+xml'};
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));}
const server=http.createServer(async(req,res)=>{
 try{
  res.setHeader('Content-Security-Policy',csp);res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=(), payment=()');
  if(!allowedFrames.length)res.setHeader('X-Frame-Options','SAMEORIGIN');
  if(req.headers.host!==publicUrl.host){json(res,403,{error:'invalid_host'});return;}
  const url=new URL(req.url,origin);
  if(basePath!=='/'){if(!url.pathname.startsWith(basePath)){json(res,404,{error:'not_found'});return;}url.pathname='/'+url.pathname.slice(basePath.length);}
  if(url.pathname==='/api/config'&&req.method==='GET'){json(res,200,{enabled:!!process.env.OPENAI_API_KEY,model:process.env.OPENAI_MODEL||'gpt-5.4-mini',csrf:token,catalogSource:process.env.CATALOG_SOURCE||'demo'});return;}
  if(['/api/catalog','/api/catalog/export','/api/catalog/schema','/api/catalog/detail'].includes(url.pathname)){
   if(req.method!=='GET'){res.setHeader('Allow','GET');throw new ServiceError('method_not_allowed',405);}
   if(url.pathname==='/api/catalog/schema'){json(res,200,getCatalogSchema());return;}
   if(url.pathname==='/api/catalog/detail'){json(res,200,await catalogDetail(url.searchParams.get('id')||''));return;}
   if(url.pathname==='/api/catalog'){const rawPage=url.searchParams.get('page');if(rawPage!==null&&!/^[1-9][0-9]{0,4}$/.test(rawPage))throw new ServiceError('invalid_page',400);json(res,200,await ensureCatalog(rawPage===null?{}:{page:Number(rawPage)}));return;}
   const format=url.searchParams.get('format')||'json';
   if(!['json','csv'].includes(format))throw new ServiceError('unsupported_format',400);
   const snapshot=await ensureCatalog(),data=format==='csv'?catalogCsv(snapshot):JSON.stringify(snapshot,null,2)+'\n';
   res.writeHead(200,{'Content-Type':format==='csv'?'text/csv; charset=utf-8':'application/json; charset=utf-8','Content-Disposition':`attachment; filename="zhanna-catalog-demo.${format}"`,'Content-Length':Buffer.byteLength(data),'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(data);return;
  }
  if(url.pathname.startsWith('/api/')&&!['GET','HEAD'].includes(req.method)){
   const given=Buffer.from(req.headers['x-ekt-token']||''),expected=Buffer.from(token);
   if(req.headers.origin!==origin||given.length!==expected.length||!timingSafeEqual(given,expected)){json(res,403,{error:'request_denied'});return;}
   if(!req.headers['content-type']?.startsWith('application/json')){json(res,415,{error:'json_required'});return;}
  }
  if(url.pathname==='/api/cart'||url.pathname.startsWith('/api/cart/')){
   const {owner,actor}=cartIdentity(req,res);
   if(url.pathname==='/api/cart'&&req.method==='GET'){json(res,200,carts.read(owner));return;}
   if(url.pathname==='/api/cart/proposals'&&req.method==='POST'){const input=await body(req);await ensureCatalog();json(res,200,carts.prepare(owner,actor,input));return;}
   if(url.pathname==='/api/cart/proposals'&&req.method==='DELETE'){json(res,200,carts.cancel(owner,actor));return;}
   if(url.pathname==='/api/cart/confirm'&&req.method==='POST'){const input=await body(req);if(input?.confirmed!==true)throw new ServiceError('confirmation_required',400);await ensureCatalog({force:true});json(res,200,carts.confirm(owner,actor,input));return;}
   throw new ServiceError('method_not_allowed',405);
  }
  if(url.pathname==='/api/privacy'&&req.method==='DELETE'){const user=store.user(cookieToken(req));if(!user||req.headers['x-ekt-user']!==user.id)throw new ServiceError('login_required',401);const input=await body(req);if(input.confirmed!==true)throw new ServiceError('confirmation_required',400);json(res,200,store.eraseHistory(user.id));return;}
  if(url.pathname==='/api/session'&&req.method==='GET'){json(res,200,{user:store.user(cookieToken(req))});return;}
  if(['/api/register','/api/login'].includes(url.pathname)&&req.method==='POST'){
   while(authRequests.length&&Date.now()-authRequests[0]>60000)authRequests.shift();
   if(authRequests.length>=15)throw new ServiceError('rate_limited',429);authRequests.push(Date.now());
   const result=await store[url.pathname==='/api/register'?'register':'login'](await body(req));
   store.logout(cookieToken(req));setSession(res,result.token);addCookie(res,'ekt_cart','',0);json(res,200,{user:result.user});return;
  }
  if(url.pathname==='/api/logout'&&req.method==='POST'){store.logout(cookieToken(req));setSession(res,'');addCookie(res,'ekt_cart','',0);json(res,200,{ok:true});return;}
  if(url.pathname==='/api/tickets'&&req.method==='POST'){
   while(ticketRequests.length&&Date.now()-ticketRequests[0]>60000)ticketRequests.shift();
   if(ticketRequests.length>=10)throw new ServiceError('rate_limited',429);ticketRequests.push(Date.now());
   const user=store.user(cookieToken(req));if(req.headers['x-ekt-user']!==(user?.id||'guest'))throw new ServiceError('login_required',401);
   json(res,201,store.ticket(user?.id,await body(req)));return;
  }
  if(url.pathname==='/api/conversations'||url.pathname.startsWith('/api/conversations/')||url.pathname==='/api/tickets'){
   const user=store.user(cookieToken(req));if(!user||req.headers['x-ekt-user']!==user.id)throw new ServiceError('login_required',401);
   if(url.pathname==='/api/tickets'&&req.method==='GET'){json(res,200,store.tickets(user.id));return;}
   if(url.pathname==='/api/conversations'){
    if(req.method==='GET'){json(res,200,store.list(user.id));return;}
    if(req.method==='POST'){json(res,200,store.save(user.id,await body(req)));return;}
   }else if(url.pathname.startsWith('/api/conversations/')){
    const id=url.pathname.slice('/api/conversations/'.length);
    if(req.method==='GET'){json(res,200,store.get(user.id,id));return;}
    if(req.method==='DELETE'){json(res,200,store.remove(user.id,id));return;}
   }
   throw new ServiceError('method_not_allowed',405);
  }
  if(url.pathname==='/api/understand'){
   if(req.method!=='POST'){json(res,405,{error:'method_not_allowed'});return;}
   const given=Buffer.from(req.headers['x-ekt-token']||'');const expected=Buffer.from(token);
   if(req.headers.origin!==origin||given.length!==expected.length||!timingSafeEqual(given,expected)){json(res,403,{error:'request_denied'});return;}
   if(!req.headers['content-type']?.startsWith('application/json')){json(res,415,{error:'json_required'});return;}
   requests=requests.filter(t=>Date.now()-t<60000);
   if(requests.length>=30||active>=2){json(res,429,{error:'rate_limited'});return;}
   const chunks=[];let size=0;
   for await(const chunk of req){size+=chunk.length;if(size>16000){json(res,413,{error:'too_large'});return;}chunks.push(chunk);}
   let input;try{input=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{json(res,400,{error:'invalid_json'});return;}
   if(input?.aiConsent!==true){json(res,403,{error:'ai_consent_required'});return;}
   requests.push(Date.now());active++;
   try{const snapshot=await ensureCatalog();json(res,200,await understand(input,process.env,fetch,snapshot.products));}finally{active--;}
   return;
  }
  if(url.pathname.startsWith('/api/')){json(res,404,{error:'not_found'});return;}
  if(!['GET','HEAD'].includes(req.method)){json(res,405,{error:'method_not_allowed'});return;}
  let relative;try{relative=decodeURIComponent(url.pathname);}catch{json(res,400,{error:'invalid_path'});return;}
  if(relative.includes('\\')||relative.includes('\0')||relative.split('/').some(p=>p.startsWith('.'))){json(res,404,{error:'not_found'});return;}
  const candidate=path.resolve(publicRoot,'.'+(relative==='/'?'/index.html':relative));
  if(!candidate.startsWith(publicRoot+path.sep)){json(res,404,{error:'not_found'});return;}
  let file;try{file=await realpath(candidate);if(!file.startsWith(publicRoot+path.sep)||!(await stat(file)).isFile())throw Error();}catch{json(res,404,{error:'not_found'});return;}
  const data=await readFile(file);res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Content-Length':data.length,'X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Cache-Control':'no-cache'});res.end(req.method==='HEAD'?undefined:data);
 }catch(e){if(!res.headersSent)json(res,e instanceof ServiceError?e.status:500,{error:e instanceof ServiceError?e.code:'internal_error'});else res.end();}
});
server.listen(port,'127.0.0.1',()=>console.log(`EKT local server: ${origin} | AI ${process.env.OPENAI_API_KEY?'configured':'not configured'}`));
