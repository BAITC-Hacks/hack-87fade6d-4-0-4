// Isolated test process only. No real partner or OpenAI network requests.
if(process.env.EKT_TEST_FIXTURES!=='1')throw Error('Test fixture requires explicit opt-in');
const nativeFetch=globalThis.fetch;
const headers={'content-type':'application/json'};
const result=data=>new Response(JSON.stringify(data),{status:200,headers});
const products=[
 {id:515291,article:'200300285_',name:'Fixture breaker 160А',price:64920},
 {id:515292,article:'0000456',name:'Fixture cable',price:120},
 {id:515293,article:'RM-TEST-3',name:'Fixture relay',price:300}
];
globalThis.fetch=async(input,options={})=>{
 const url=new URL(String(input));
 if(url.origin==='https://ekt.kz'){
  const expected='Basic '+Buffer.from(process.env.EKT_API_USERNAME+':'+process.env.EKT_API_PASSWORD).toString('base64');
  if(options.headers?.Authorization!==expected||options.redirect!=='error'||options.method!=='GET')throw Error('Unsafe partner request');
  if(url.pathname==='/api/products'){
   const page=Number(url.searchParams.get('page')||1);return result({page,per_page:20,count:1,items:products[page-1]?[products[page-1]]:[]});
  }
  if(url.pathname==='/api/products/detail'){
   const product=products.find(p=>String(p.id)===url.searchParams.get('id'));if(!product)return new Response('{}',{status:404,headers});
   return result({...product,quantity:23,stores:[{id:13,name:'Fixture warehouse',quantity:23}],url:'https://ekt.kz/catalog/fixture/',properties:{CML2_ARTICLE:product.article,TORGOVAYA_MARKA:'Fixture',NOMINALNYY_TOK:product.id===515291?'250 А':'',KRATNOST_MIN:'1'}});
  }
  throw Error('Unexpected EKT route');
 }
 if(url.origin==='https://api.openai.com'){
  const payload=JSON.parse(options.body),ids=payload.text.format.schema.properties.product_ids.items.enum;
  if(!ids.includes('515291')||ids.includes('D-101')||payload.store!==false||payload.instructions.includes(process.env.EKT_API_PASSWORD))throw Error('Incorrect model catalog or secret disclosure');
  return result({status:'completed',output:[{content:[{type:'output_text',text:JSON.stringify({intent:'product',product_ids:['515291'],quantity:null})}]}]});
 }
 return nativeFetch(input,options);
};
