import {randomBytes} from 'node:crypto';
import {catalogSnapshot} from './catalog.mjs';
export {catalogSnapshot} from './catalog.mjs';
import {ServiceError} from './ai.mjs';
const fail=(code,status=409)=>{throw new ServiceError(code,status);};
export function createCartService(db,getCatalog=catalogSnapshot,now=Date.now){
 db.exec(`CREATE TABLE IF NOT EXISTS carts(owner TEXT PRIMARY KEY,version INTEGER NOT NULL,items TEXT NOT NULL,updated INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS cart_proposals(id TEXT PRIMARY KEY,owner TEXT NOT NULL,actor TEXT NOT NULL,version INTEGER NOT NULL,items TEXT NOT NULL,catalog_revision TEXT NOT NULL,expires INTEGER NOT NULL,used INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS cart_audit(id TEXT PRIMARY KEY,owner TEXT NOT NULL,version INTEGER NOT NULL,items TEXT NOT NULL,confirmed_at INTEGER NOT NULL);`);
 const read=owner=>{const row=db.prepare('SELECT * FROM carts WHERE owner=?').get(owner);return row?{version:row.version,items:JSON.parse(row.items)}:{version:0,items:[]};};
 const validate=(items,products)=>{
  if(!Array.isArray(items)||!items.length||items.length>200)fail('invalid_cart',400);
  const totals=new Map();
  for(const item of items){if(!item||Object.keys(item).some(k=>!['id','qty','unit'].includes(k)))fail('invalid_cart',400);const p=products.find(p=>p.id===item.id);if(!p||item.unit!==p.unit||!Number.isFinite(item.qty)||item.qty<p.minOrder||!Number.isInteger(item.qty/p.step))fail('invalid_cart',400);totals.set(p.id,(totals.get(p.id)||0)+item.qty);if(totals.get(p.id)>p.stock)fail('insufficient_stock');}
  return [...totals].map(([id,qty])=>({product:products.find(p=>p.id===id),qty}));
 };
 const inputRows=items=>items.map(r=>({id:r.product.id,qty:r.qty,unit:r.product.unit}));
 const purge=()=>{db.prepare('DELETE FROM cart_proposals WHERE expires<?').run(now()-86400000);db.prepare('DELETE FROM cart_audit WHERE confirmed_at<?').run(now()-30*86400000);};
 return {
  read,
  cancel(owner,actor){db.prepare('DELETE FROM cart_proposals WHERE owner=? AND actor=? AND used=0').run(owner,actor);return {ok:true};},
  prepare(owner,actor,input){purge();if(!input||!['add','replace'].includes(input.mode)||Object.keys(input).some(k=>!['mode','items','version'].includes(k)))fail('invalid_cart',400);const current=read(owner);if(input.version!==current.version)fail('cart_changed');const snap=getCatalog();const added=validate(input.items,snap.products);const items=validate(input.mode==='add'?[...inputRows(current.items),...inputRows(added)]:inputRows(added),snap.products);const id=randomBytes(32).toString('hex'),expires=now()+5*60000;
   this.cancel(owner,actor);db.prepare('INSERT INTO cart_proposals(id,owner,actor,version,items,catalog_revision,expires) VALUES(?,?,?,?,?,?,?)').run(id,owner,actor,current.version,JSON.stringify(items),snap.revision,expires);
   return {id,version:current.version,items,total:items.reduce((s,r)=>s+r.qty*r.product.price,0),expires,source:snap.source,verifiedAt:snap.verifiedAt,mode:input.mode};
  },
  confirm(owner,actor,input){if(!input||input.confirmed!==true||typeof input.proposalId!=='string'||Object.keys(input).some(k=>!['confirmed','proposalId'].includes(k)))fail('confirmation_required',400);
   const proposal=db.prepare('SELECT * FROM cart_proposals WHERE id=? AND owner=? AND actor=?').get(input.proposalId,owner,actor);if(!proposal)fail('invalid_proposal',403);
   const current=read(owner);if(proposal.used){if(current.version===proposal.version+1)return {...current,replayed:true};fail('cart_changed');}
   if(proposal.expires<now())fail('proposal_expired');if(current.version!==proposal.version)fail('cart_changed');const snap=getCatalog();if(snap.revision!==proposal.catalog_revision)fail('catalog_changed');
   const items=validate(inputRows(JSON.parse(proposal.items)),snap.products);if(JSON.stringify(items)!==proposal.items)fail('catalog_changed');
   db.exec('BEGIN IMMEDIATE');try{db.prepare('INSERT INTO carts VALUES(?,?,?,?) ON CONFLICT(owner) DO UPDATE SET version=excluded.version,items=excluded.items,updated=excluded.updated').run(owner,current.version+1,JSON.stringify(items),now());db.prepare('UPDATE cart_proposals SET used=1 WHERE id=?').run(proposal.id);db.prepare('INSERT INTO cart_audit VALUES(?,?,?,?,?)').run(proposal.id,owner,current.version+1,JSON.stringify(inputRows(items)),now());db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}
   return {version:current.version+1,items};
  }
 };
}
