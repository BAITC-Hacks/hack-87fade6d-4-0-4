import http from 'node:http';
import {readFile,stat,realpath} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {understand,ServiceError} from './server/ai.mjs';
import {createStore} from './server/store.mjs';

const root=path.dirname(fileURLToPath(import.meta.url));
try{const text=await readFile(path.join(root,'.env.local'),'utf8');for(const line of text.split(/\r?\n/)){const m=line.match(/^([A-Z_]+)=(.*)$/);if(m&&['OPENAI_API_KEY','OPENAI_MODEL'].includes(m[1])&&!process.env[m[1]])process.env[m[1]]=m[2].trim();}}catch{}
const publicRoot=await realpath(path.join(root,'dist'));const port=Number(process.env.PORT||8080);const origin=`http://127.0.0.1:${port}`;
const token=randomBytes(32).toString('hex');let active=0,requests=[];
const store=createStore(process.env.EKT_DATA_DIR||path.join(root,'.data'));
const authRequests=[];const ticketRequests=[];
const cookieToken=req=>(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('ekt_session='))?.slice(12)||'';
const setSession=(res,value)=>res.setHeader('Set-Cookie',`ekt_session=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${value?604800:0}`);
async function body(req){let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>1000000)throw new ServiceError('too_large',413);chunks.push(chunk);}try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw new ServiceError('invalid_json',400);}}
const types={'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.txt':'text/plain; charset=utf-8','.wasm':'application/wasm','.gz':'application/gzip','.svg':'image/svg+xml'};
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));}
const server=http.createServer(async(req,res)=>{
 try{
  if(req.headers.host!==`127.0.0.1:${port}`){json(res,403,{error:'invalid_host'});return;}
  const url=new URL(req.url,origin);
  if(url.pathname==='/api/config'&&req.method==='GET'){json(res,200,{enabled:!!process.env.OPENAI_API_KEY,model:process.env.OPENAI_MODEL||'gpt-5.4-mini',csrf:token});return;}
  if(url.pathname.startsWith('/api/')&&!['GET','HEAD'].includes(req.method)){
   const given=Buffer.from(req.headers['x-ekt-token']||''),expected=Buffer.from(token);
   if(req.headers.origin!==origin||given.length!==expected.length||!timingSafeEqual(given,expected)){json(res,403,{error:'request_denied'});return;}
   if(!req.headers['content-type']?.startsWith('application/json')){json(res,415,{error:'json_required'});return;}
  }
  if(url.pathname==='/api/session'&&req.method==='GET'){json(res,200,{user:store.user(cookieToken(req))});return;}
  if(['/api/register','/api/login'].includes(url.pathname)&&req.method==='POST'){
   while(authRequests.length&&Date.now()-authRequests[0]>60000)authRequests.shift();
   if(authRequests.length>=15)throw new ServiceError('rate_limited',429);authRequests.push(Date.now());
   const result=await store[url.pathname==='/api/register'?'register':'login'](await body(req));
   store.logout(cookieToken(req));setSession(res,result.token);json(res,200,{user:result.user});return;
  }
  if(url.pathname==='/api/logout'&&req.method==='POST'){store.logout(cookieToken(req));setSession(res,'');json(res,200,{ok:true});return;}
  if(url.pathname==='/api/tickets'&&req.method==='POST'){
   while(ticketRequests.length&&Date.now()-ticketRequests[0]>60000)ticketRequests.shift();
   if(ticketRequests.length>=10)throw new ServiceError('rate_limited',429);ticketRequests.push(Date.now());
   const user=store.user(cookieToken(req));if(req.headers['x-ekt-user']!==(user?.id||'guest'))throw new ServiceError('login_required',401);
   json(res,201,store.ticket(user?.id,await body(req)));return;
  }
  if(url.pathname==='/api/conversations'||url.pathname.startsWith('/api/conversations/')||url.pathname==='/api/tickets'){
   const user=store.user(cookieToken(req));if(!user||req.headers['x-ekt-user']!==user.id)throw new ServiceError('login_required',401);
   if(url.pathname==='/api/tickets'&&req.method==='GET'){json(res,200,store.tickets(user.id));return;}
   if(url.pathname==='/api/conversations'){
    if(req.method==='GET'){json(res,200,store.list(user.id));return;}
    if(req.method==='POST'){json(res,200,store.save(user.id,await body(req)));return;}
   }else if(url.pathname.startsWith('/api/conversations/')){
    const id=url.pathname.slice('/api/conversations/'.length);
    if(req.method==='GET'){json(res,200,store.get(user.id,id));return;}
    if(req.method==='DELETE'){json(res,200,store.remove(user.id,id));return;}
   }
   throw new ServiceError('method_not_allowed',405);
  }
  if(url.pathname==='/api/understand'){
   if(req.method!=='POST'){json(res,405,{error:'method_not_allowed'});return;}
   const given=Buffer.from(req.headers['x-ekt-token']||'');const expected=Buffer.from(token);
   if(req.headers.origin!==origin||given.length!==expected.length||!timingSafeEqual(given,expected)){json(res,403,{error:'request_denied'});return;}
   if(!req.headers['content-type']?.startsWith('application/json')){json(res,415,{error:'json_required'});return;}
   requests=requests.filter(t=>Date.now()-t<60000);
   if(requests.length>=30||active>=2){json(res,429,{error:'rate_limited'});return;}
   const chunks=[];let size=0;
   for await(const chunk of req){size+=chunk.length;if(size>16000){json(res,413,{error:'too_large'});return;}chunks.push(chunk);}
   let input;try{input=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{json(res,400,{error:'invalid_json'});return;}
   requests.push(Date.now());active++;
   try{json(res,200,await understand(input,process.env));}finally{active--;}
   return;
  }
  if(url.pathname.startsWith('/api/')){json(res,404,{error:'not_found'});return;}
  if(!['GET','HEAD'].includes(req.method)){json(res,405,{error:'method_not_allowed'});return;}
  let relative;try{relative=decodeURIComponent(url.pathname);}catch{json(res,400,{error:'invalid_path'});return;}
  if(relative.includes('\\')||relative.includes('\0')||relative.split('/').some(p=>p.startsWith('.'))){json(res,404,{error:'not_found'});return;}
  const candidate=path.resolve(publicRoot,'.'+(relative==='/'?'/index.html':relative));
  if(!candidate.startsWith(publicRoot+path.sep)){json(res,404,{error:'not_found'});return;}
  let file;try{file=await realpath(candidate);if(!file.startsWith(publicRoot+path.sep)||!(await stat(file)).isFile())throw Error();}catch{json(res,404,{error:'not_found'});return;}
  const data=await readFile(file);res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Content-Length':data.length,'X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Cache-Control':'no-cache'});res.end(req.method==='HEAD'?undefined:data);
 }catch(e){if(!res.headersSent)json(res,e instanceof ServiceError?e.status:500,{error:e instanceof ServiceError?e.code:'internal_error'});else res.end();}
});
server.listen(port,'127.0.0.1',()=>console.log(`EKT local server: ${origin} | AI ${process.env.OPENAI_API_KEY?'configured':'not configured'}`));
