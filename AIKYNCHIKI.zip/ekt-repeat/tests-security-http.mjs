import assert from 'node:assert/strict';import {spawn} from 'node:child_process';import {mkdtemp,rm} from 'node:fs/promises';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';
const cwd=path.dirname(fileURLToPath(import.meta.url)),dir=await mkdtemp(path.join(os.tmpdir(),'ekt-security-http-')),origin='http://127.0.0.1:8083',base=origin+'/zhanna/';
const child=spawn(process.execPath,['server.mjs'],{cwd,env:{...process.env,CATALOG_SOURCE:'demo',PORT:'8083',BASE_PATH:'/zhanna/',EKT_DATA_DIR:dir},stdio:['ignore','pipe','pipe'],windowsHide:true});
await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('timeout')),10000);child.stdout.on('data',()=>{clearTimeout(timer);resolve();});child.once('exit',code=>{clearTimeout(timer);reject(Error('exit '+code));});});
let csrf=(await(await fetch(base+'api/config')).json()).csrf,cookie='';
async function call(route,method='GET',data,extra={}){const r=await fetch(base+'api/'+route,{method,headers:{Origin:origin,'Content-Type':'application/json','X-EKT-Token':csrf,'X-EKT-User':'guest',Cookie:cookie,...extra},...(data===undefined?{}:{body:JSON.stringify(data)})});return {status:r.status,body:await r.json(),headers:r.headers};}
try{
 const home=await fetch(base);assert.match(home.headers.get('content-security-policy'),/frame-ancestors 'self'/);assert.equal(home.headers.get('referrer-policy'),'no-referrer');assert.equal(home.headers.get('x-frame-options'),'SAMEORIGIN');assert.equal((await fetch(origin+'/api/config')).status,404);
 assert.equal((await fetch(base+'widget.mjs')).status,200);assert.equal((await fetch(base+'embed-demo.html')).status,200);
 const initial=await call('cart');cookie=initial.headers.get('set-cookie').split(';')[0];assert.match(initial.headers.get('set-cookie'),/Path=\/zhanna\//);assert.match(initial.headers.get('set-cookie'),/HttpOnly/);
 const p=await call('cart/proposals','POST',{mode:'add',version:0,items:[{id:'D-101',qty:2,unit:'шт'}]});assert.equal(p.status,200);assert.equal((await call('cart')).body.items.length,0);
 assert.equal((await call('cart/confirm','POST',{proposalId:p.body.id})).status,400);
 assert.equal((await call('cart/confirm','POST',{proposalId:p.body.id,confirmed:true},{Origin:'https://bad.test'})).status,403);
 assert.equal((await call('cart/confirm','POST',{proposalId:p.body.id,confirmed:true},{Cookie:''})).status,403);
 assert.equal((await call('cart/confirm','POST',{proposalId:p.body.id,confirmed:true})).body.items[0].qty,2);
 assert.equal((await call('cart/confirm','POST',{proposalId:p.body.id,confirmed:true})).body.items[0].qty,2);
 assert.equal((await call('cart','POST',{items:[]})).status,405);
 assert.equal((await call('orders','POST',{})).status,404);
 assert.equal((await call('understand','POST',{text:'D-101'})).body.error,'ai_consent_required');
 assert.equal((await call('understand','POST',{text:'CVV: 123',aiConsent:true})).body.error,'sensitive_input');
 assert.equal((await call('tickets','POST',{issue:'Позвоните менеджеру',contact:'PIN: 1234'})).status,400);
 console.log('PASS HTTP: mounted /zhanna/ paths; security headers; HttpOnly cart; explicit confirmation; Origin; foreign-session denial; replay protection; no direct mutation/order endpoint; AI consent; payment guard.');
}finally{if(child.exitCode===null)await new Promise(resolve=>{child.once('exit',resolve);child.kill();});if(path.resolve(dir).startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(dir).startsWith('ekt-security-http-'))await rm(dir,{recursive:true,force:true});}
