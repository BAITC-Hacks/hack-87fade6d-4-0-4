import assert from 'node:assert/strict';import {spawn} from 'node:child_process';import {mkdtemp,rm} from 'node:fs/promises';import path from 'node:path';import os from 'node:os';import {fileURLToPath} from 'node:url';
const cwd=path.dirname(fileURLToPath(import.meta.url)),dir=await mkdtemp(path.join(os.tmpdir(),'ekt-http-test-')),origin='http://127.0.0.1:8082';let child;
async function start(){child=spawn(process.execPath,['server.mjs'],{cwd,env:{...process.env,CATALOG_SOURCE:'demo',PORT:'8082',EKT_DATA_DIR:dir},stdio:['ignore','pipe','pipe'],windowsHide:true});await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('server startup timeout')),10000);child.stdout.on('data',()=>{clearTimeout(timer);resolve();});child.once('exit',code=>{clearTimeout(timer);reject(Error('server exited '+code));});});return (await(await fetch(origin+'/api/config')).json()).csrf;}
async function stop(){if(child?.exitCode===null){await new Promise(resolve=>{child.once('exit',resolve);child.kill();});}}
let csrf=await start();
async function call(endpoint,{method='GET',data,cookie='',uid='guest',token=csrf,requestOrigin=origin}={}){const response=await fetch(origin+'/api/'+endpoint,{method,headers:{Origin:requestOrigin,'Content-Type':'application/json','X-EKT-Token':token,'X-EKT-User':uid,Cookie:cookie},...(data===undefined?{}:{body:JSON.stringify(data)})});return {status:response.status,body:await response.json(),cookie:response.headers.get('set-cookie')};}
try{
 assert.equal((await call('conversations')).status,401);
 assert.equal((await call('register',{method:'POST',requestOrigin:'https://untrusted.test',data:{}})).status,403);
 const a=await call('register',{method:'POST',data:{email:'alpha@example.test',password:'test-alpha-2026'}}),b=await call('register',{method:'POST',data:{email:'beta@example.test',password:'test-beta-2026'}});assert.equal(a.status,200);assert.match(a.cookie,/HttpOnly/);assert.match(a.cookie,/SameSite=Strict/);
 const ca=a.cookie.split(';')[0],cb=b.cookie.split(';')[0],ua=a.body.user.id,ub=b.body.user.id;
 const saved=await call('conversations',{method:'POST',cookie:ca,uid:ua,data:{messages:[{role:'user',text:'D-201 бар ма?'}],lastId:'D-201'}});assert.equal(saved.status,200);const id=saved.body.id;
 for(const method of ['GET','DELETE'])assert.equal((await call('conversations/'+id,{method,cookie:cb,uid:ub,...(method==='DELETE'?{data:{}}:{})})).status,404);
 assert.equal((await call('conversations',{method:'POST',cookie:cb,uid:ua,data:{messages:[]}})).status,401);
 assert.equal((await call('conversations',{method:'POST',cookie:cb,uid:ub,data:{id,messages:[]}})).status,404);
 assert.equal((await call('conversations',{cookie:ca,uid:ua})).body.length,1);
 const ticket=await call('tickets',{method:'POST',cookie:ca,uid:ua,data:{issue:'Нужен менеджер для подбора',includeTranscript:false,messages:[{role:'user',text:'private'}]}});assert.equal(ticket.status,201);assert.equal(ticket.body.manager,'iconofyourlife');assert.equal(ticket.body.transcript.length,0);assert.equal((await call('tickets',{cookie:cb,uid:ub})).body.length,0);
 for(const url of ['/.env.local','/.data/app.sqlite','/server/store.mjs','/../.env.local'])assert.equal((await fetch(origin+url)).status,404);
 await stop();csrf=await start();assert.equal((await call('conversations/'+id,{cookie:ca,uid:ua})).body.messages[0].text,'D-201 бар ма?');
 assert.equal((await call('logout',{method:'POST',cookie:ca,uid:ua,data:{}})).status,200);assert.equal((await call('conversations',{cookie:ca,uid:ua})).status,401);
 console.log('PASS HTTP: CSRF, cookie flags, authorization, cross-account isolation, tickets, private files blocked, history survives server restart, logout.');
}finally{await stop();if(path.resolve(dir).startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(dir).startsWith('ekt-http-test-'))await rm(dir,{recursive:true,force:true});}
