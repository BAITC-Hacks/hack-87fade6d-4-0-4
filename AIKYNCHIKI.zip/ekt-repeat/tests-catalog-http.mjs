import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {parseDelimited} from './dist/core.mjs';
import {catalogCsv} from './server/catalog.mjs';

const cwd=path.dirname(fileURLToPath(import.meta.url));
const children=[],directories=[];
async function start(port,source){
 const dir=await mkdtemp(path.join(os.tmpdir(),'ekt-catalog-http-'));directories.push(dir);
 const origin=`http://127.0.0.1:${port}`;
 const child=spawn(process.execPath,['server.mjs'],{cwd,env:{...process.env,PORT:String(port),PUBLIC_ORIGIN:origin,BASE_PATH:'/zhanna/',CATALOG_SOURCE:source,EKT_DATA_DIR:dir,OPENAI_API_KEY:'disabled-for-catalog-test'},stdio:['ignore','pipe','pipe'],windowsHide:true});children.push(child);
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Server start timed out')),10000);child.stdout.once('data',()=>{clearTimeout(timer);resolve();});child.once('error',error=>{clearTimeout(timer);reject(error);});child.once('exit',code=>{clearTimeout(timer);reject(Error('Server exited: '+code));});});
 return {origin,base:origin+'/zhanna/'};
}
// Validate the schema vocabulary used by our published contract, without a network dependency.
function conforms(value,schema,root=schema,location='$'){
 if(schema.$ref){const target=schema.$ref.split('/').slice(1).reduce((node,key)=>node[key],root);return conforms(value,target,root,location);}
 if(schema.anyOf){assert.ok(schema.anyOf.some(option=>{try{conforms(value,option,root,location);return true;}catch{return false;}}),location+' anyOf');return;}
 if('const' in schema)assert.deepEqual(value,schema.const,location+' const');
 if(schema.enum)assert.ok(schema.enum.includes(value),location+' enum');
 if(schema.type){const type=value===null?'null':Array.isArray(value)?'array':typeof value;assert.ok(schema.type==='integer'?Number.isInteger(value):type===schema.type,location+' type');}
 if(typeof value==='number'){assert.ok(Number.isFinite(value),location+' finite');if(schema.minimum!==undefined)assert.ok(value>=schema.minimum,location+' minimum');if(schema.exclusiveMinimum!==undefined)assert.ok(value>schema.exclusiveMinimum,location+' exclusiveMinimum');}
 if(typeof value==='string'){if(schema.minLength)assert.ok(value.length>=schema.minLength,location+' minLength');if(schema.pattern)assert.match(value,new RegExp(schema.pattern),location+' pattern');if(schema.format==='date-time')assert.ok(Number.isFinite(Date.parse(value)),location+' date-time');if(schema.format==='uri-reference')assert.ok(new URL(value,'http://127.0.0.1/'),location+' uri-reference');}
 if(Array.isArray(value)){if(schema.minItems)assert.ok(value.length>=schema.minItems,location+' minItems');if(schema.items)value.forEach((item,index)=>conforms(item,schema.items,root,location+'['+index+']'));}
 else if(value&&typeof value==='object'){for(const key of schema.required||[])assert.ok(Object.hasOwn(value,key),location+' required '+key);for(const [key,item] of Object.entries(value)){if(schema.additionalProperties===false)assert.ok(Object.hasOwn(schema.properties||{},key),location+' unexpected '+key);if(schema.properties?.[key])conforms(item,schema.properties[key],root,location+'.'+key);}}
}
try{
 const {base,origin}=await start(8084,'demo');
 const response=await fetch(base+'api/catalog');assert.equal(response.status,200);assert.equal(response.headers.get('cache-control'),'no-store');
 const snapshot=await response.json(),schema=await(await fetch(base+'api/catalog/schema')).json();
 conforms(snapshot,schema);assert.equal(snapshot.total,24);assert.equal(snapshot.products.length,24);assert.equal(new Set(snapshot.products.map(p=>p.id)).size,24);assert.equal(snapshot.warehouses.length,3);assert.equal(snapshot.source,'demo');assert.equal(snapshot.isSynthetic,true);
 const offline=JSON.parse(await readFile(path.join(cwd,'data/catalog-sample.json'),'utf8')),offlineSchema=JSON.parse(await readFile(path.join(cwd,'data/catalog.schema.json'),'utf8'));conforms(offline,offlineSchema);assert.deepEqual(offlineSchema,schema);assert.equal(offline.revision,snapshot.revision);assert.deepEqual(offline.products,snapshot.products);assert.equal(await readFile(path.join(cwd,'data/catalog-sample.csv'),'utf8'),catalogCsv(offline));
 assert.ok(new Set(snapshot.products.map(p=>p.category)).size>=8);assert.deepEqual(new Set(snapshot.products.map(p=>p.availability)),new Set(['in_stock','limited_stock','out_of_stock']));
 const available=n=>n===0?'out_of_stock':n<=10?'limited_stock':'in_stock';
 for(const product of snapshot.products){assert.equal(product.stock,product.warehouses.reduce((sum,w)=>sum+w.stock,0));assert.equal(product.availability,available(product.stock));assert.deepEqual(product.warehouses.map(w=>w.id),snapshot.warehouses.map(w=>w.id));for(const w of product.warehouses)assert.equal(w.status,available(w.stock));assert.equal(product.currency,'KZT');}
 const document=snapshot.products.find(p=>p.id==='D-101').certificates[0];assert.equal(document.isSample,true);const doc=await fetch(new URL(document.url,base));assert.equal(doc.status,200);assert.match(await doc.text(),/демонстрац|образец/i);
 const second=await(await fetch(base+'api/catalog')).json();assert.equal(second.revision,snapshot.revision);assert.deepEqual(second.products,snapshot.products);
 const download=await fetch(base+'api/catalog/export?format=json');assert.equal(download.status,200);assert.match(download.headers.get('content-disposition'),/attachment; filename="zhanna-catalog-demo\.json"/);const json=await download.json();conforms(json,schema);assert.deepEqual(json.products,snapshot.products);
 const csv=await fetch(base+'api/catalog/export?format=csv');assert.equal(csv.status,200);assert.match(csv.headers.get('content-type'),/text\/csv; charset=utf-8/);assert.match(csv.headers.get('content-disposition'),/zhanna-catalog-demo\.csv/);const bytes=new Uint8Array(await csv.arrayBuffer());assert.deepEqual([...bytes.slice(0,3)],[239,187,191]);const csvText=new TextDecoder().decode(bytes);assert.match(csvText,/Автоматический выключатель/);assert.match(csvText,/Алматы/);const rows=parseDelimited(csvText);assert.equal(rows.length,25);const columns=rows[0],field=(row,name)=>row[columns.indexOf(name)];assert.equal(field(rows[1],'id'),'D-101');assert.deepEqual(JSON.parse(field(rows[1],'warehouses')),snapshot.products[0].warehouses);assert.equal(JSON.parse(field(rows[1],'certificates'))[0].isSample,true);assert.ok(rows.slice(1).every(row=>field(row,'isSynthetic')==='true'&&field(row,'source')==='demo'));
 const multiline=structuredClone(snapshot);multiline.products=multiline.products.slice(0,1);multiline.products[0].name='Товар; "образец"\nвторая строка';assert.equal(parseDelimited(catalogCsv(multiline))[1][1],multiline.products[0].name);
 const unsupported=await fetch(base+'api/catalog/export?format=xlsx');assert.equal(unsupported.status,400);assert.equal((await unsupported.json()).error,'unsupported_format');
 for(const endpoint of ['api/catalog','api/catalog/export','api/catalog/schema']){const write=await fetch(base+endpoint,{method:'POST'});assert.equal(write.status,405);assert.equal(write.headers.get('allow'),'GET');}
 assert.equal((await fetch(origin+'/api/catalog')).status,404);
 const unavailable=await start(8085,'partner');for(const endpoint of ['api/catalog','api/catalog/export?format=csv']){const failure=await fetch(unavailable.base+endpoint);assert.equal(failure.status,503);assert.equal((await failure.json()).error,'catalog_unavailable');}
 const config=await(await fetch(unavailable.base+'api/config')).json();const cart=await fetch(unavailable.base+'api/cart',{headers:{'X-EKT-User':'guest'}});const rejected=await fetch(unavailable.base+'api/cart/proposals',{method:'POST',headers:{Origin:unavailable.origin,'Content-Type':'application/json','X-EKT-Token':config.csrf,'X-EKT-User':'guest',Cookie:cart.headers.get('set-cookie').split(';')[0]},body:JSON.stringify({mode:'add',version:0,items:[{id:'D-101',qty:1,unit:'шт'}]})});assert.equal(rejected.status,503);
 console.log('PASS catalog API: 24 structured synthetic products; schema; 3 warehouse totals/statuses; sample certificate; mounted JSON/UTF-8 CSV downloads; multiline quoting; read-only endpoints; unavailable source fails closed for catalog and cart.');
}finally{
 for(const child of children)if(child.exitCode===null)await new Promise(resolve=>{child.once('exit',resolve);child.kill();});
 for(const dir of directories)if(path.resolve(dir).startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(dir).startsWith('ekt-catalog-http-'))await rm(dir,{recursive:true,force:true});
}
