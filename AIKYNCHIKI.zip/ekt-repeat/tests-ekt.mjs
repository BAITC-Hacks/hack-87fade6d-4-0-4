import assert from 'node:assert/strict';
import {createEktClient,normalizeEktProduct,EKT_PRICE_CURRENCY} from './server/ekt-client.mjs';
import {ServiceError} from './server/ai.mjs';

// Self-contained fake responses match the authorized API probe's field shapes.
// Generated list items are test data; no live catalogue or credentials are
// bundled. The compact detail below preserves the observed 160 A / 250 A
// contradiction and warehouse categories needed to exercise normalization.
const testPage=page=>({page,per_page:20,count:20,items:Array.from({length:20},(_,index)=>{
 const id=page===2&&index===0?515291:100000+(page-1)*20+index+1;
 return {id,article:'TEST-'+id,name:'Тестовый товар '+id,price:100+index,image:null,url:'https://ekt.kz/catalog/test-'+id+'/',url_api_detail:'https://ekt.kz/api/products/detail?id='+id,offers:[]};
})});
const page1=testPage(1),page2=testPage(2);
const storeNames=['Брак MEGALIGHT','Шымкент (ул.Байдукова)','Маркетинг MEGALIGHT','Никонов','РЦ MEGALIGHT','Талдыкорган','Тастак','Торговый зал','Востановленный продукт','перемещение','Основной склад','Алматы','ЩИТОВОЕ','РЦ UNIT','Образцы Отдел Закупа','Витрина ТЗ','Усть-Каменогорск','Тараз','Атырау','Караганда','Новосибирск','Актау','Нур-Султан','Шымкент (Тассай)'];
const storeQuantities=[0,2,0,0,0,0,0,0,0,0,0,5,0,0,0,0,0,2,3,2,0,0,8,1];
const detailFixture={
 id:515291,name:'027228 АВ DRX250 MT 3ф 160А 18ka Legrand (1)',article:'200300285_',price:64920,quantity:23,
 stores:storeNames.map((name,index)=>({id:index+2,name,quantity:storeQuantities[index]})),
 image:null,url:'https://ekt.kz/catalog/test-breaker/',offers:[],
 properties:{CML2_ARTICLE:'200300285_',RECOMMEND:['48783','23466','28727'],CML2_BAR_CODE:'3414970344526',CML2_TRAITS:['Готовая продукция','Товар','200300285_'],KRATNOST_MIN:'1',ARTIKULPOSTAVSHCHIKA:'027228',KOLICHESTVO_POLYUSOV:'3',NOMINALNAYA_OTKLYUCHAYUSHCHAYA_SPOSOBNOST:'18кА',NOMINALNOE_NAPRYAZHENIE:'400В',NOMINALNYY_TOK:'250 А',TIP_USTANOVKI:'Винтовое',TORGOVAYA_MARKA:'Legrand'}
};
const env={EKT_API_USERNAME:'fake-user',EKT_API_PASSWORD:'fake-password-only-for-tests'};
const clone=value=>structuredClone(value);
const unavailable=error=>error instanceof ServiceError&&error.code==='catalog_unavailable'&&error.status===503&&error.message==='catalog_unavailable';
const response=(body,status=200,headers={})=>new Response(typeof body==='string'?body:JSON.stringify(body),{status,headers:{'content-type':'application/json',...headers}});
let count=0;
async function test(name,run){await run();count++;console.log('ok '+count+' - '+name);}

function fakeApi(){
 const state={calls:[],failure:null,active:0,maxActive:0,delay:0,mutateDetail:null,mutatePage:null};
 const listed=new Map([...page1.items,...page2.items].map(item=>[String(item.id),item]));
 state.fetch=async(url,options)=>{
  state.calls.push({url,options});
  assert.equal(new URL(url).origin,'https://ekt.kz');
  assert.equal(options.method,'GET');
  assert.equal(options.redirect,'error');
  assert.equal(options.headers.Authorization,'Basic '+Buffer.from(env.EKT_API_USERNAME+':'+env.EKT_API_PASSWORD).toString('base64'));
  assert.equal(options.headers.Accept,'application/json');
  assert.ok(options.signal instanceof AbortSignal);
  if(state.failure)return typeof state.failure==='function'?state.failure(url):response({error:'upstream text must stay private'},state.failure);
  const parsed=new URL(url);
  if(parsed.pathname==='/api/products'){
   const page=Number(parsed.searchParams.get('page'));
   let data=page===1?clone(page1):page===2?clone(page2):{page,per_page:20,count:1,items:[{id:900000+page,article:'TEST-'+page,name:'Fake API page '+page,price:12}]};
   if(state.mutatePage)data=state.mutatePage(data);
   return response(data);
  }
  assert.equal(parsed.pathname,'/api/products/detail');
  const id=parsed.searchParams.get('id');
  state.active++;state.maxActive=Math.max(state.maxActive,state.active);
  try{
   if(state.delay)await new Promise(resolve=>setTimeout(resolve,state.delay));
   let data=id===String(detailFixture.id)?clone(detailFixture):listed.has(id)?{...clone(listed.get(id)),quantity:0,stores:[],properties:{}}:{id:Number(id),article:'TEST-'+id,name:'Fake API item '+id,price:12};
   if(state.mutateDetail)data=state.mutateDetail(data);
   return response(data);
  }finally{state.active--;}
 };
 return state;
}

await test('observed detail shape keeps internal ID and exact article aliases; unknown trade terms stay null',()=>{
 const p=normalizeEktProduct(detailFixture);
 assert.equal(p.id,'515291');assert.equal(p.article,'200300285_');assert.equal(p.supplierArticle,'027228');
 assert.deepEqual(p.aliases,['515291','200300285_','027228']);
 assert.equal(p.name,detailFixture.name);assert.equal(p.price,64920);assert.equal(p.brand,'Legrand');
 for(const key of ['unit','minOrder','step','group','sourceUpdatedAt'])assert.equal(p[key],null,key);
 assert.equal(p.category,'Не указана в API');assert.equal(p.categoryKnown,false);
 assert.equal(p.currency,'KZT');assert.equal(p.currencyKnown,true);assert.equal(p.currencySource,'project_config');
 assert.equal(p.rulesKnown,false);assert.equal(p.purchasable,false);assert.equal(p.isSynthetic,false);assert.equal(p.source,'ekt');
 assert.equal(p.fetchedAt,undefined);
 assert.deepEqual(p.certificates,[]);assert.equal(p.certificate,null);
 assert.deepEqual(p.relatedIds,['48783','23466','28727']);
 assert.equal(p.stock,23);assert.equal(p.warehouseTotal,23);assert.equal(p.warehouses.length,24);
 assert.equal(p.warehouseFulfillmentKnown,false);assert.equal(p.warehouseStockMeaning,'raw_api_stock');
 assert.equal(p.warehouses.find(w=>w.id==='2').name,'Брак MEGALIGHT');
 assert.equal(p.warehouses.find(w=>w.id==='11').name,'перемещение');
 assert.equal(p.warehouses.find(w=>w.id==='13').stock,5);
 assert.ok(p.attributes.some(item=>item.name==='KRATNOST_MIN'&&item.value==='1'));
 assert.ok(!p.attributes.some(item=>/CML2_|BAR_CODE/.test(item.name)));
 assert.ok(!JSON.stringify(p).includes('3414970344526'));
 assert.ok(!p.spec.includes('KRATNOST_MIN'));
 assert.ok(p.spec.includes('Номинальный ток: 250 А'));
 assert.equal(p.analogEligible,false);assert.ok(p.warnings.some(w=>w.includes('160 А')&&w.includes('250 А')));
});

await test('missing and malformed price/quantity are unknown, never guessed from warehouse sums or names',()=>{
 const p=normalizeEktProduct({id:123,name:'Коробка (20 шт) KZT',price:'12',stores:[{id:1,name:'Склад',quantity:7},{id:2,name:'В пути',quantity:-1}],properties:{KRATNOST_MIN:'20'}});
 assert.equal(p.price,null);assert.equal(p.unit,null);assert.equal(p.currency,'KZT');assert.equal(p.stock,null);assert.equal(p.availability,'unknown');
 assert.equal(p.warehouseTotal,7);assert.equal(p.warehouseTotalComplete,false);assert.equal(p.warehouses[1].stock,null);assert.equal(p.warehouses[1].status,'unknown');
 assert.equal(p.minOrder,null);assert.equal(p.step,null);assert.equal(p.spec,'');assert.equal(p.brand,null);assert.equal(p.analogEligible,false);
 for(const quantity of [null,undefined,-1,'5',NaN,Infinity])assert.equal(normalizeEktProduct({id:1,name:'Товар',quantity}).stock,null);
 assert.equal(normalizeEktProduct({id:1,name:'Товар',quantity:0}).availability,'out_of_stock');
 assert.equal(normalizeEktProduct({id:1,name:'Товар',quantity:0.5}).availability,'in_stock');
});

await test('project currency uses tenge without converting prices or inventing units and purchase rules',()=>{
 assert.equal(EKT_PRICE_CURRENCY,'KZT');
 for(const price of [0,12.75,64920]){
  const p=normalizeEktProduct({id:1,name:'Товар',price,quantity:10,properties:{KRATNOST_MIN:'1'}});
  assert.equal(p.price,price);assert.equal(p.currency,'KZT');assert.equal(p.currencyKnown,true);assert.equal(p.currencySource,'project_config');
  assert.equal(p.unit,null);assert.equal(p.minOrder,null);assert.equal(p.step,null);assert.equal(p.rulesKnown,false);assert.equal(p.purchasable,false);
  assert.ok(!p.warnings.some(w=>/валют/i.test(w)));
  assert.ok(p.warnings.some(w=>w.includes('Единица продажи')));assert.ok(p.warnings.some(w=>w.includes('шаг заказа')));
 }
 assert.equal(normalizeEktProduct({id:1,name:'Товар без цены'}).price,null);
});

await test('certificate and external URLs exclude unsafe schemes, credentials and foreign product origins',()=>{
 const p=normalizeEktProduct({id:1,name:'Товар',url:'https://evil.example/catalog',image:'https://ekt.kz.evil.example/a.png',certificates:[
  {url:'javascript:alert(1)'},{url:'http://ekt.kz/a.pdf'},{url:'https://user:secret@ekt.kz/a.pdf'},
  {url:'https://docs.example.test/certificate.pdf',label:'Сертификат соответствия'},
  {url:'https://docs.example.test/certificate.pdf',label:'Дубликат'}
 ]});
 assert.equal(p.externalUrl,null);assert.equal(p.image,null);assert.equal(p.certificates.length,1);assert.equal(p.certificates[0].isSample,false);
 assert.equal(p.certificate.url,'https://docs.example.test/certificate.pdf');
 assert.equal(normalizeEktProduct({id:1,name:'Товар',url:'https://ekt.kz/catalog/item/'}).externalUrl,'https://ekt.kz/catalog/item/');
});

await test('documented technical labels and explicit technical properties produce specifications without internal metadata',()=>{
 const p=normalizeEktProduct({id:1,name:'Выключатель 16А',technicalproperties:[{name:'Материал корпуса',value:'Пластик'},{name:'Номинальный ток',value:'16',unit:'А'},{name:'CML2_TRAITS',value:'Internal'}]});
 assert.equal(p.analogEligible,true);assert.ok(p.spec.includes('Материал корпуса: Пластик'));assert.ok(p.spec.includes('16 А'));
 assert.equal(p.attributes.length,2);assert.ok(!p.spec.includes('Internal'));
 const q=normalizeEktProduct({id:2,name:'Коробка',technicalproperties:{WIDTH_CODE:'20',Ширина:{value:'20',unit:'мм'},CML2_BAR_CODE:'1234'}});
 assert.deepEqual(q.attributes,[{name:'Ширина',value:'20',unit:'мм'}]);
});

await test('default load fetches exactly pages 1 and 2 plus 40 details, at most four at once',async()=>{
 const fake=fakeApi();fake.delay=2;
 const client=createEktClient({env,fetchImpl:fake.fetch,now:()=>1000});
 assert.throws(()=>client.snapshot(),unavailable);
 const snapshot=await client.load();
 assert.equal(snapshot.schemaVersion,'1.1');assert.equal(snapshot.products.length,40);assert.equal(snapshot.total,40);
 assert.deepEqual(snapshot.coverage,{pages:[1,2],fullCatalog:false,hasMore:true,nextPage:3});
 assert.equal(snapshot.currency,'KZT');assert.equal(snapshot.currencyKnown,true);assert.equal(snapshot.currencySource,'project_config');
 assert.ok(snapshot.products.every(p=>p.currency===snapshot.currency&&p.currencySource===snapshot.currencySource));
 assert.equal(snapshot.dataUpdatedAt,null);assert.equal(snapshot.verifiedAt,1000);
 assert.equal(snapshot.warehouses.length,24);assert.ok(snapshot.warehouses.every(w=>w.city===null));
 assert.equal(fake.calls.length,42);assert.equal(fake.calls.filter(call=>new URL(call.url).pathname==='/api/products').length,2);
 assert.equal(fake.maxActive,4);assert.ok(fake.calls.every(call=>!call.url.includes('url_api_detail')));
 assert.match(snapshot.revision,/^[a-f0-9]{64}$/);
 const serialized=JSON.stringify(snapshot);assert.ok(!serialized.includes(env.EKT_API_USERNAME));assert.ok(!serialized.includes(env.EKT_API_PASSWORD));assert.ok(!serialized.includes('Basic '));
 snapshot.products[0].name='Local mutation';assert.notEqual(client.snapshot().products[0].name,'Local mutation');
});

await test('fresh cache avoids HTTP; expiry and force revalidate all loaded pages with a stable business revision',async()=>{
 let clock=1000;const fake=fakeApi();const client=createEktClient({env,fetchImpl:fake.fetch,now:()=>clock});
 const first=await client.load();const calls=fake.calls.length;
 clock=60_999;assert.deepEqual(await client.load(),first);assert.equal(fake.calls.length,calls);
 assert.equal((await client.detail(515291)).id,'515291');assert.equal(fake.calls.length,calls);
 clock=61_000;assert.throws(()=>client.snapshot(),unavailable);
 const refreshed=await client.load();assert.equal(fake.calls.length,calls*2);assert.equal(refreshed.revision,first.revision);assert.notEqual(refreshed.verifiedAt,first.verifiedAt);
 assert.deepEqual(refreshed.products,first.products);
 clock=61_001;const forced=await client.load({force:true});assert.equal(fake.calls.length,calls*3);assert.equal(forced.revision,first.revision);
});

await test('upstream auth failure returns a generic 503 and never substitutes stale cached products',async()=>{
 const fake=fakeApi();const client=createEktClient({env,fetchImpl:fake.fetch,now:()=>1000});
 const first=await client.load();fake.failure=401;
 await assert.rejects(()=>client.load({force:true}),unavailable);assert.throws(()=>client.snapshot(),unavailable);
 await assert.rejects(()=>client.load(),unavailable);
 fake.failure=null;assert.equal((await client.load()).revision,first.revision);
 fake.failure=403;await assert.rejects(()=>client.detail(515291,{force:true}),unavailable);assert.throws(()=>client.snapshot(),unavailable);
});

await test('missing credentials, hostile exception messages and redirect responses reveal no secrets',async()=>{
 let calls=0;
 const missing=createEktClient({env:{},fetchImpl:async()=>{calls++;throw new Error('should not fetch');}});
 await assert.rejects(()=>missing.load(),unavailable);assert.equal(calls,0);
 const throwing=createEktClient({env,fetchImpl:async()=>{throw new Error(env.EKT_API_PASSWORD);}});
 await assert.rejects(()=>throwing.load(),unavailable);
 for(const bad of [response('secret',302),{ok:true,redirected:true,url:'https://ekt.kz/api/products?page=1'},{ok:true,url:'https://evil.example/api/products?page=1'}]){
  await assert.rejects(()=>createEktClient({env,fetchImpl:async()=>bad}).load(),unavailable);
 }
});

await test('fixed detail URLs ignore upstream url_api_detail and detail responses must match requested ID',async()=>{
 const fake=fakeApi();fake.mutatePage=data=>({...data,items:data.items.map(item=>({...item,url_api_detail:'https://evil.example/steal-credentials'}))});
 const client=createEktClient({env,fetchImpl:fake.fetch});await client.load({page:1});
 assert.ok(fake.calls.every(call=>call.url.startsWith('https://ekt.kz/api/products')));
 fake.mutateDetail=data=>({...data,id:999999});await assert.rejects(()=>client.detail(515291),unavailable);
});

await test('explicit pages merge atomically, count is page size rather than grand total, and empty pages end pagination',async()=>{
 const fake=fakeApi();const client=createEktClient({env,fetchImpl:fake.fetch,now:()=>1000});
 const first=await client.load({page:1});assert.equal(first.total,20);assert.equal(first.coverage.nextPage,2);
 const second=await client.load({page:2});assert.equal(second.total,40);assert.deepEqual(second.coverage.pages,[1,2]);assert.equal(fake.calls.length,42);
 const third=await client.load({page:3});assert.equal(third.total,41);assert.equal(third.coverage.hasMore,false);assert.equal(third.coverage.nextPage,null);
 assert.equal(fake.calls.length,44);
 fake.mutatePage=data=>({...data,items:[],count:0});
 const fourth=await client.load({page:4});assert.equal(fourth.total,41);assert.deepEqual(fourth.coverage.pages,[1,2,3,4]);assert.equal(fourth.coverage.hasMore,false);
});

await test('page inputs and ten-page cap are bounded; duplicate IDs fetch once and appear once',async()=>{
 const fake=fakeApi();const client=createEktClient({env,fetchImpl:fake.fetch,now:()=>1000});
 for(const page of [0,-1,1.5,10001,'2',null,NaN,Infinity])await assert.rejects(()=>client.load({page}),error=>error.code==='invalid_catalog_page'&&error.status===400);
 assert.equal(fake.calls.length,0);
 fake.mutatePage=data=>({...data,items:[clone(page1.items[0]),clone(page1.items[0])]});
 for(let page=1;page<=10;page++)await client.load({page});
 assert.equal(client.snapshot().total,1);assert.equal(fake.calls.length,20);
 await assert.rejects(()=>client.load({page:11}),error=>error.code==='catalog_page_limit'&&error.status===400);assert.equal(fake.calls.length,20);
 for(const id of ['../secret','https://evil.example',-1,null,0,1.5])await assert.rejects(()=>client.detail(id),error=>error.code==='invalid_catalog_id'&&error.status===400);
});

await test('body size, invalid JSON and malformed API envelopes are rejected generically',async()=>{
 const bodies=[response('x'.repeat(2*1024*1024+1)),response('{}',200,{'content-length':String(2*1024*1024+1)}),response('{invalid'),response({items:{}}),response({page:2,per_page:20,items:[]}),response({page:1,per_page:20,items:[{id:'bad',name:'Invalid'}]})];
 for(const body of bodies)await assert.rejects(()=>createEktClient({env,fetchImpl:async()=>body}).load({page:1}),unavailable);
});

await test('15-second request deadline aborts hanging requests without including provider secrets',async()=>{
 const realSetTimeout=globalThis.setTimeout;
 let signal,requestedDelay;
 try{
  // Advance this one timeout immediately instead of slowing the test by 15 s.
  globalThis.setTimeout=(callback,delay,...args)=>{requestedDelay=delay;return realSetTimeout(callback,0,...args);};
  const client=createEktClient({env,fetchImpl:async(_url,options)=>{signal=options.signal;return new Promise(()=>{});}});
  await assert.rejects(()=>client.load(),unavailable);
  assert.equal(requestedDelay,15_000);assert.equal(signal.aborted,true);
 }finally{globalThis.setTimeout=realSetTimeout;}
});

await test('failed detail batch cannot publish a partial page and waits for its in-flight requests',async()=>{
 const fake=fakeApi();fake.delay=2;
 const client=createEktClient({env,fetchImpl:fake.fetch,now:()=>1000});const first=await client.load({page:1});
 fake.mutateDetail=data=>{if(data.id===515291)throw new Error('upstream private detail');return data;};
 await assert.rejects(()=>client.load({page:2}),unavailable);assert.equal(fake.active,0);assert.throws(()=>client.snapshot(),unavailable);
 fake.mutateDetail=null;
 const restored=await client.load();assert.deepEqual(restored.coverage.pages,[1]);assert.equal(restored.total,first.total);
});

await test('detail cache refresh changes business revision without extending page freshness',async()=>{
 let clock=1000;const fake=fakeApi();const client=createEktClient({env,fetchImpl:fake.fetch,now:()=>clock});
 const first=await client.load();fake.mutateDetail=data=>({...data,price:data.price+1});
 clock=10_000;const detail=await client.detail(515291,{force:true});assert.equal(detail.price,64921);
 const updated=client.snapshot();assert.notEqual(updated.revision,first.revision);assert.equal(updated.verifiedAt,first.verifiedAt);
 assert.equal(updated.products.find(p=>p.id==='515291').price,64921);
 clock=61_000;assert.throws(()=>client.snapshot(),unavailable);
});

console.log('EKT provider: '+count+' fake-fetch checks passed; no live API calls.');
