import { mkdir, writeFile, rename } from 'node:fs/promises';
import { EktCatalog } from '../server/catalog.mjs';
const catalog = new EktCatalog(), items = [], seen = new Set();
let complete = false;
for(let page = 1; page <= 10000; page++) {
  const data = await catalog.request(`products?page=${page}`);
  if (!Array.isArray(data.items)) throw Error('Некорректный ответ API.');
  if (!data.items.length) { complete = true; break; }
  let added = 0;
  for(const p of data.items) if(!seen.has(p.id)) { seen.add(p.id); added++; items.push({id:p.id,article:p.article,name:p.name}); }
  if (!added) throw Error('API повторяет страницу; индекс не заменён.');
  if (page % 20 === 0) console.log(`Загружено ${items.length} товаров`);
  if (data.items.length < data.per_page) { complete = true; break; }
}
if(!complete) throw Error('Достигнут предел страниц; индекс не заменён.');
const dir = new URL('../data/',import.meta.url);
await mkdir(dir,{recursive:true});
await writeFile(new URL('ekt-index.tmp',dir),JSON.stringify({fetchedAt:new Date().toISOString(),complete,items}));
await rename(new URL('ekt-index.tmp',dir),new URL('ekt-index.json',dir));
console.log(`Индекс сохранён: ${items.length} товаров. Цены и остатки при запросах читаются заново.`);
