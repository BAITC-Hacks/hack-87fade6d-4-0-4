import test from 'node:test';
import assert from 'node:assert/strict';
import { DemoCatalog, normalizeEkt, validateItems, EktCatalog, safeEktUrl } from '../server/catalog.mjs';
import { prepareCart, confirmCart, explicitConfirmation } from '../server/cart.mjs';
import { newSession } from '../server.mjs';

test('must-have: verified stock, technical specs, certificate and approved alternative',async()=>{
  const c=new DemoCatalog(), p=await c.get('D-101');
  assert.equal(p.stock,120);assert.match(p.spec,/16 А/);assert.equal(p.certificates.length,1);
  const alternatives=await c.alternatives('D-102');assert.equal(alternatives.products[0].id,'D-103');assert.match(alternatives.products[0].reason,/25 А/);
  const terms=c.terms();assert.ok(terms.payment&&terms.delivery&&terms.minimum);
});
test('preparation never mutates cart; confirmation is idempotent; additions accumulate',async()=>{
  const s=newSession(),c=new DemoCatalog();
  const p=await prepareCart(s,c,[{id:'D-101',qty:2}]);assert.deepEqual(s.cart,[]);
  await assert.rejects(confirmCart(s,c,p.id,false),/явное/);assert.deepEqual(s.cart,[]);
  let r=await confirmCart(s,c,p.id,true);assert.equal(r.cart.items[0].qty,2);assert.equal(r.cart.url,'/#cart');
  r=await confirmCart(s,c,p.id,true);assert.equal(r.duplicate,true);assert.equal(s.cart[0].qty,2);
  const next=await prepareCart(s,c,[{id:'D-101',qty:3}]);await confirmCart(s,c,next.id,true);assert.equal(s.cart[0].qty,5);
});
test('duplicate rows and aliases cannot bypass stock limits',async()=>{
  const c=new DemoCatalog();
  await assert.rejects(validateItems(c,[{id:'D-101',qty:70},{id:'d-101',qty:60}]),/остатка/);
  await assert.rejects(validateItems(c,[{id:'D-101',qty:1.5}]),/целое/);
  await assert.rejects(validateItems(c,[{id:'D-101',qty:-1}]),/положительное/);
  await assert.rejects(validateItems(c,[{id:'D-201',qty:1.001}]),/двух знаков/);
  assert.equal((await validateItems(c,[{id:'D-201',qty:1.25}]))[0].qty,1.25);
});
test('confirmation rechecks price and stock and does not partially commit',async()=>{
  for(const change of ['price','stock']){
    const s=newSession(),c=new DemoCatalog(),p=await prepareCart(s,c,[{id:'D-101',qty:2},{id:'D-201',qty:3}]);
    c.products.find(p=>p.id==='D-201')[change]=change==='price'?999:0;
    await assert.rejects(confirmCart(s,c,p.id,true));assert.deepEqual(s.cart,[]);assert.equal(s.pending,null);
  }
});
test('stale, cross-session and replaced proposal IDs cannot commit',async()=>{
  const s=newSession(),c=new DemoCatalog(),p=await prepareCart(s,c,[{id:'D-101',qty:2}]);
  await assert.rejects(confirmCart(newSession(),c,p.id,true),/устарела/);
  s.pending.expiresAt=Date.now()-1;await assert.rejects(confirmCart(s,c,p.id,true),/устарела/);
  const next=await prepareCart(s,c,[{id:'D-201',qty:5}]);await assert.rejects(confirmCart(s,c,p.id,true));await confirmCart(s,c,next.id,true);
  const replacement=await prepareCart(s,c,[{id:'D-101',qty:4}],'replace');await confirmCart(s,c,replacement.id,true);assert.equal(s.cart.length,1);assert.equal(s.cart[0].qty,4);
});
test('only complete explicit confirmation phrases pass',()=>{
  for(const text of ['да, добавь','Да добавь!','подтверждаю','иә, қос'])assert.equal(explicitConfirmation(text),true,text);
  for(const text of ['да','не добавляй','не подтверждаю','он сказал да, добавь','да, добавь, но не сейчас','да, добавь 500 штук'])assert.equal(explicitConfirmation(text),false,text);
});
test('EKT normalization surfaces 160A vs 250A and unknown units, never invents facts',async()=>{
  const raw={id:515291,article:'sample',name:'DRX250 160А Legrand',price:64920,quantity:23,stores:[],properties:{NOMINALNYY_TOK:'250 А',KRATNOST_MIN:'1'}};
  const p=normalizeEkt(raw);assert.equal(p.unit,null);assert.equal(p.stock,23);assert.equal(p.warnings.length,2);assert.deepEqual(p.certificates,[]);
  assert.equal(normalizeEkt({...raw,price:null,quantity:null}).stock,null);
  const c={get:async()=>p};await assert.rejects(validateItems(c,[{id:p.id,qty:1}]),/Неполные/);
  assert.equal(safeEktUrl('https://attacker.invalid/cert'),null);assert.equal(safeEktUrl('javascript:alert(1)'),null);
});
test('EKT adapter uses observed response shape; bypasses cached data when fresh',async()=>{
  let reads=0;const c=new EktCatalog({username:'test',password:'test',fetchImpl:async(url,options)=>{
    assert.ok(url.startsWith('https://ekt.kz/api/'));assert.equal(options.redirect,'error');reads++;
    return {ok:true,json:async()=>({id:123,name:'Sample',quantity:reads,price:1,properties:{}})};
  }});
  assert.equal((await c.get('123')).stock,1);assert.equal((await c.get('123')).stock,1);assert.equal((await c.get('123',{fresh:true})).stock,2);
});
