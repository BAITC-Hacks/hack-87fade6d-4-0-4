import assert from 'node:assert/strict';
import {catalog,match,identifierMatches,alternatives,validate,isStepMultiple,purchaseBlockReason} from './dist/core.mjs';
import {answer,createConsultant,searchProducts,quantityFrom,formatMoney} from './dist/consultant.mjs';
import {recommendations,explainAlternative} from './dist/recommendations.mjs';

const original=structuredClone(catalog);
const live=(id,extra={})=>({id,name:'Товар '+id,article:id,aliases:[id],source:'ekt',isSynthetic:false,price:null,currency:null,unit:null,minOrder:null,step:null,rulesKnown:false,purchasable:false,stock:null,warehouses:[],group:null,spec:'',analogEligible:false,warnings:[],certificates:[],...extra});
const sale=(id,extra={})=>live(id,{price:10,currency:'KZT',unit:'шт',minOrder:1,step:1,rulesKnown:true,purchasable:true,stock:10,...extra});
const row=(product,qty=1)=>({product,qty,unit:product.unit});
try{
 const main=live('515291',{name:'Автоматический выключатель 160A',article:'ВА-160/3',aliases:['515291','ВА-160/3','00160'],price:200,stock:5,warnings:['Валюта в API отсутствует.','Единица в API отсутствует.','Противоречие: в названии 160 А, в характеристиках 250 А.']});
 const zero=live('00123'),plain=live('123'),cyrillic=live('Х-01'),latin=live('X-01');
 catalog.splice(0,catalog.length,main,zero,plain,cyrillic,latin);
 assert.equal(match({sku:'00123'}),zero);assert.equal(match({sku:'123'}),plain);
 assert.equal(match({sku:'ва-160/3'}),main);assert.equal(match({sku:'00160'}),main);
 assert.equal(match({sku:'999',name:main.name}),null);
 assert.deepEqual(searchProducts('Покажи 515291').map(p=>p.id),['515291']);
 assert.deepEqual(searchProducts('Есть ва-160/3?').map(p=>p.id),['515291']);
 assert.deepEqual(searchProducts('Х-01').map(p=>p.id),['Х-01']);
 assert.deepEqual(searchProducts('X-01').map(p=>p.id),['X-01']);
 for(const text of ['X515291','5152910','515291-20','001234','1.515291'])assert.equal(identifierMatches(text).length,0,text);
 assert.equal(identifierMatches('Есть 515291.').length,1);
 assert.equal(identifierMatches('NEW-1',[live('NEW-1')])[0].product.id,'NEW-1');
 assert.equal(identifierMatches('Код: КОД+[123].',[live('КОД+[123]')])[0].product.id,'КОД+[123]');
 assert.equal(quantityFrom('Добавь 515291'),null);assert.equal(quantityFrom('Добавь 00123'),null);
 assert.equal(quantityFrom('Добавь 2 шт 515291'),2);assert.equal(quantityFrom('00123 3 дана қос'),3);
 assert.equal(quantityFrom('515291 2,5 м добавь'),2.5);
 let state=createConsultant();let result=answer('Добавь 515291',state,[]);
 assert.match(result.text,/количество/);assert.equal(result.confirm,undefined);assert.equal(state.pending,null);
 result=answer('Добавь 2 шт 515291',state,[]);assert.equal(result.confirm,undefined);assert.equal(result.escalate,true);
 assert.equal(answer('Да, добавь',state,[]).commit,undefined);
 result=answer('Покажи 00123',state,[]);assert.match(result.text,/EKT API/);assert.match(result.text,/не указано/);assert.doesNotMatch(result.text,/нулевой остаток/);
 result=answer('Покажи 515291',state,[]);assert.match(result.text,/уточнить валюту, единицу и правила продажи/);assert.match(result.text,/Противоречие: в названии 160 А, в характеристиках 250 А/);assert.doesNotMatch(result.text,/Валюта в API отсутствует|Единица в API отсутствует/);assert.equal(result.escalate,true);
 result=answer('Какие условия оплаты и доставки?',state,[]);assert.match(result.text,/EKT API не предоставляет/);assert.doesNotMatch(result.text,/Алматы|картой/);
 assert.match(formatMoney(100,null),/валюта не указана/);assert.doesNotMatch(formatMoney(100,null),/₸/);assert.match(formatMoney(null),/неизвестна/);assert.match(formatMoney(100),/₸/);
 const collision=live('other',{article:'ВА-160/3',aliases:['ВА-160/3']});catalog.push(collision);
 assert.equal(match({sku:'ВА-160/3'}),null);assert.equal(searchProducts('ВА-160/3').length,2);
 assert.deepEqual(alternatives(zero),[]);assert.match(explainAlternative(zero,plain),/не подтверждена/);

 const p=sale('sale');catalog.splice(0,catalog.length,p);
 p.name='Стабилизатор напряжения';assert.equal(searchProducts('Покажи стабилизатор')[0],p);
 for(const key of ['price','currency','unit','minOrder','step','stock']){
  for(const unknown of [null,undefined]){const saved=p[key];p[key]=unknown;assert.ok(purchaseBlockReason(p),key);assert.throws(()=>validate([row(p)]),/менеджер/,key);p[key]=saved;}
 }
 p.purchasable=false;assert.throws(()=>validate([row(p)]),/не подтверждены/);p.purchasable=true;
 p.rulesKnown=false;assert.throws(()=>validate([row(p)]),/правила/);p.rulesKnown=true;
 p.warnings=['160 А / 250 А'];assert.throws(()=>validate([row(p)]),/противоречия/);p.warnings=[];
 const foreign=sale('foreign',{currency:'USD'});catalog.push(foreign);assert.throws(()=>validate([row(p),row(foreign)]),/разные валюты/);
 Object.assign(p,{unit:'м',minOrder:.1,step:.1,stock:.3});assert.equal(isStepMultiple(.3,.1),true);assert.equal(isStepMultiple(.31,.1),false);
 assert.equal(validate([row(p,.1),row(p,.2)])[0].qty,.3);assert.throws(()=>validate([row(p,.4)]),/Недостаточно/);
 Object.assign(p,{unit:'шт',minOrder:1,step:1,stock:10});state=createConsultant();result=answer('Добавь 2 шт sale',state,[]);assert.equal(result.confirm,true);assert.equal(state.pending.qty,2);assert.equal(answer('Да, добавь',state,[]).commit[0].qty,2);

 const a=sale('a',{group:'g',spec:'1P 16A',analogEligible:false}),b=sale('b',{group:'g',spec:'1P 16A',analogEligible:false});catalog.splice(0,catalog.length,a,b);
 assert.deepEqual(alternatives(a),[]);a.analogEligible=b.analogEligible=true;assert.deepEqual(alternatives(a).map(p=>p.id),['b']);b.warnings=['проверить'];assert.deepEqual(alternatives(a),[]);b.warnings=[];
 a.relatedIds=['b','missing'];assert.deepEqual(recommendations(['a']).map(r=>r.product.id),['b']);assert.match(recommendations(['a'])[0].reason,/RECOMMEND/);assert.equal(recommendations(['a'],[{product:b,qty:1}]).length,0);
 catalog.splice(0,catalog.length,live('D-201'),live('D-401'));assert.equal(recommendations(['D-201']).length,0);
 console.log('PASS: live identifiers, unknown facts, explicit confirmation, decimal quantities, analogues and supplied RECOMMEND relations.');
}finally{catalog.splice(0,catalog.length,...original);}
