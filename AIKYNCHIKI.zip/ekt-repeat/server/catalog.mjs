import {createHash} from 'node:crypto';
import {catalogSeed,catalogMetadata} from '../dist/catalog-data.mjs';
import {ServiceError} from './ai.mjs';
import {createEktClient,EKT_PRICE_CURRENCY} from './ekt-client.mjs';

let ektClient;
const selectedSource=()=>process.env.CATALOG_SOURCE||'demo';
const partner=()=>ektClient??=(createEktClient({env:process.env}));
export async function ensureCatalog(options={}){
 if(selectedSource()==='ekt')return partner().load(options);
 if(selectedSource()!=='demo')throw new ServiceError('catalog_unavailable',503);
 if(options.page!==undefined&&options.page!==1)throw new ServiceError('invalid_page',400);
 return catalogSnapshot();
}
export async function catalogDetail(id){
 if(selectedSource()==='ekt')return partner().detail(id);
 const product=catalogSnapshot().products.find(p=>p.id===id);
 if(!product)throw new ServiceError('product_not_found',404);
 return product;
}

// This provider intentionally has no fallback from live data to demonstration data.
export function catalogSnapshot(){
 if(selectedSource()==='ekt')return partner().snapshot();
 if(selectedSource()!=='demo')throw new ServiceError('catalog_unavailable',503);
 const data={...structuredClone(catalogMetadata),products:structuredClone(catalogSeed)};
 return {...data,total:data.products.length,verifiedAt:Date.now(),revision:createHash('sha256').update(JSON.stringify(data)).digest('hex')};
}

const status={type:'string',enum:['in_stock','limited_stock','out_of_stock']};
const text={type:'string',minLength:1};
const quantity={type:'number',minimum:0};
export const catalogSchema={
 $schema:'https://json-schema.org/draft/2020-12/schema',
 title:'Жанна AI — синтетический каталог и остатки, версия 1.0',
 description:'Полный снимок демонстрационного каталога. Это не данные магазина EKT. verifiedAt — время выдачи снимка, dataUpdatedAt — время изменения набора. Относительные ссылки документов разрешаются относительно корня приложения, включая BASE_PATH.',
 type:'object',additionalProperties:false,
 required:['schemaVersion','source','isSynthetic','dataUpdatedAt','warehouses','total','verifiedAt','revision','products'],
 properties:{
  schemaVersion:{const:'1.0'},source:{const:'demo'},isSynthetic:{const:true},
  dataUpdatedAt:{type:'string',format:'date-time'},verifiedAt:{type:'integer',minimum:0},
  revision:{type:'string',pattern:'^[a-f0-9]{64}$'},total:{type:'integer',minimum:1},
  warehouses:{type:'array',minItems:1,items:{type:'object',additionalProperties:false,required:['id','name','city'],properties:{id:text,name:text,city:text}}},
  products:{type:'array',minItems:1,items:{$ref:'#/$defs/product'}}
 },
 $defs:{
  certificate:{type:'object',additionalProperties:false,required:['url','label','isSample'],properties:{url:{type:'string',format:'uri-reference'},label:text,isSample:{const:true}}},
  product:{type:'object',additionalProperties:false,
   required:['id','name','category','brand','group','spec','attributes','price','currency','unit','stock','availability','warehouses','minOrder','step','certificate','certificates'],
   properties:{
    id:text,name:text,category:text,brand:text,group:text,spec:text,
    attributes:{type:'array',minItems:1,items:{type:'object',additionalProperties:false,required:['name','value'],properties:{name:text,value:text,unit:text}}},
    price:{type:'number',minimum:0},currency:{const:'KZT'},unit:text,stock:quantity,availability:status,
    warehouses:{type:'array',minItems:1,items:{type:'object',additionalProperties:false,required:['id','name','stock','status'],properties:{id:text,name:text,stock:quantity,status}}},
    minOrder:{type:'number',exclusiveMinimum:0},step:{type:'number',exclusiveMinimum:0},
    certificate:{description:'Совместимое поле прежнего интерфейса. Предпочтительное поле для интеграции — certificates.',anyOf:[{type:'null'},{type:'object',additionalProperties:false,required:['url','label'],properties:{url:{type:'string',format:'uri-reference'},label:text}}]},
    certificates:{type:'array',items:{$ref:'#/$defs/certificate'}}
   }
  }
 }
};

export const liveCatalogSchema={
 $schema:'https://json-schema.org/draft/2020-12/schema',title:'Жанна AI — нормализованный ответ тестового API EKT',
 description:'Частичная выборка из авторизованного API. Валюта цен KZT (тенге) задана настройкой проекта, не полем исходного API; числовая цена не пересчитывается. null означает, что поле не предоставлено или не подтверждено. Остатки API не гарантируют доступность для продажи. Дополнительные поля допускаются.',
 type:'object',required:['schemaVersion','source','isSynthetic','verifiedAt','products','total','revision','warehouses','coverage','currency','currencyKnown','currencySource'],
 properties:{schemaVersion:{type:'string'},source:{const:'ekt'},isSynthetic:{const:false},verifiedAt:{type:'number'},dataUpdatedAt:{type:['string','null']},revision:{type:'string'},total:{type:'integer'},
  currency:{const:EKT_PRICE_CURRENCY},currencyKnown:{const:true},currencySource:{const:'project_config',description:'Валюта цен выбрана владельцем проекта; это не поле исходного API.'},
  coverage:{type:'object',properties:{pages:{type:'array',items:{type:'integer'}},fullCatalog:{const:false},hasMore:{type:'boolean'},nextPage:{type:['integer','null']}}},
  warehouses:{type:'array',items:{type:'object',required:['id','name'],properties:{id:{type:'string'},name:{type:'string'},city:{type:['string','null']}}}},
  products:{type:'array',items:{type:'object',required:['id','name','article','price','stock','unit','currency','currencyKnown','currencySource','availability','warehouses','attributes','certificates','purchasable','warnings'],properties:{
   id:{type:'string',description:'Внутренний ID EKT, не артикул'},article:{type:'string'},aliases:{type:'array',items:{type:'string'}},name:{type:'string'},category:{type:'string'},categoryKnown:{type:'boolean'},brand:{type:['string','null']},
   price:{type:['number','null'],minimum:0},currency:{const:EKT_PRICE_CURRENCY},currencyKnown:{const:true},currencySource:{const:'project_config'},unit:{type:['string','null']},stock:{type:['number','null'],minimum:0},warehouseTotal:{type:['number','null']},availability:{enum:['in_stock','out_of_stock','limited_stock','unknown']},
   minOrder:{type:['number','null']},step:{type:['number','null']},rulesKnown:{type:'boolean'},purchasable:{type:'boolean'},warnings:{type:'array',items:{type:'string'}},
   attributes:{type:'array',items:{type:'object',required:['name','value'],properties:{name:{type:'string'},value:{type:'string'},unit:{type:'string'}}}},
   warehouses:{type:'array',items:{type:'object',required:['id','name','stock','status'],properties:{id:{type:'string'},name:{type:'string'},stock:{type:['number','null']},status:{enum:['in_stock','out_of_stock','limited_stock','unknown']}}}},
   certificates:{type:'array',items:{type:'object',required:['url','label','isSample'],properties:{url:{type:'string',format:'uri-reference'},label:{type:'string'},isSample:{type:'boolean'}}}}
  }}}
 }
};
export const getCatalogSchema=()=>selectedSource()==='ekt'?liveCatalogSchema:catalogSchema;

// A full row contains nested fields as JSON so warehouse and attribute structure survives CSV export.
const csvColumns=['id','name','category','brand','article','spec','attributes','certificates','price','currency','unit','stock','availability','warehouses','minOrder','step','source','isSynthetic','schemaVersion','dataUpdatedAt','warnings','purchasable'];
const csvCell=value=>{
 let text=typeof value==='object'?JSON.stringify(value):String(value??'');
 // Harmless for the fixed synthetic set, and prevents formulas if a later provider supplies labels.
 if(/^[=+@\-\t\r]/.test(text))text="'"+text;
 return '"'+text.replaceAll('"','""')+'"';
};
export function catalogCsv(snapshot){
 const columns=snapshot.source==='ekt'?[...csvColumns,'currencySource']:csvColumns;
 const rows=snapshot.products.map(product=>columns.map(key=>csvCell(key in product?product[key]:snapshot[key])).join(';'));
 return '\uFEFF'+[columns.map(csvCell).join(';'),...rows].join('\r\n')+'\r\n';
}
