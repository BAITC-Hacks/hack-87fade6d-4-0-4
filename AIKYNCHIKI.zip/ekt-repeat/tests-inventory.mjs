import assert from 'node:assert/strict';
import {catalog,purchaseBlockReason} from './dist/core.mjs';
import {answer,createConsultant} from './dist/consultant.mjs';
import {inventoryRequest,inventoryPage,isInventoryRequest,INVENTORY_PAGE_SIZE} from './dist/inventory.mjs';
import {setLanguage} from './dist/locale.mjs';
import {understand,toCanonical} from './server/ai.mjs';

const original=structuredClone(catalog);
const sale=(id,stock)=>({id,name:'Товар '+id,price:25,currency:'KZT',unit:'шт',minOrder:1,step:1,stock,warehouses:[],source:'demo',isSynthetic:true,warnings:[]});
try{
 const questions=['Что есть в наличии?','Покажи все товары в наличии','Какие товары сейчас есть на складе?','Что у вас есть?','Что имеется в наличии?','Қоймада не бар?','Қандай тауарлар бар?','Қолда бар тауарларды көрсет','Қоймадағы тауарларды көрсетіңіз'];
 for(const text of questions)assert.deepEqual(inventoryRequest(text),{page:1},text);
 for(const text of ['Есть D-101?','Какие автоматы есть в наличии?','Что есть в наличии из кабелей?','D-999 в наличии?','Есть 00123?','Его наличие','А он есть в наличии?','Добавь 2 шт D-101','Что не в наличии?','Открой корзину','D-101 бар ма?','Кабель бар ма?','Осы тауар бар ма?','Нужен менеджер','Что есть в наличии? Страница 0'])assert.equal(isInventoryRequest(text),false,text);
 assert.deepEqual(inventoryRequest('Что есть в наличии? Страница 2'),{page:2});
 assert.deepEqual(inventoryRequest('Қоймада не бар? Бет 3'),{page:3});

 const positive=Array.from({length:14},(_,index)=>sale('SKU-'+(index+1),index+.5));
 const excluded=[0,null,undefined,NaN,Infinity,-Infinity,-2,'5'].map((stock,index)=>sale('UNKNOWN-'+index,stock));
 catalog.splice(0,catalog.length,...positive,...excluded);
 const state=createConsultant();state.lastId='UNKNOWN-0';
 let result=answer('Что есть в наличии?',state,[]);
 assert.equal(state.lastId,null,'a general request must discard the previous product context');
 assert.equal(result.inventory.total,14);assert.equal(result.inventory.pages,3);assert.equal(result.products.length,INVENTORY_PAGE_SIZE);
 assert.deepEqual(result.products,positive.slice(0,6));assert.match(result.text,/1–6 из 14/);assert.match(result.text,/страница 1 из 3/);
 assert.equal(result.confirm,undefined);assert.equal(result.commit,undefined);
 const pages=[result,...[2,3].map(page=>answer('Что есть в наличии? Страница '+page,state,[]))];
 assert.deepEqual(pages.flatMap(page=>page.products.map(product=>product.id)),positive.map(product=>product.id),'all available products are reachable without duplicate or omitted rows');
 assert.match(pages[2].text,/13–14 из 14/);assert.equal(pages[2].products.length,2);
 assert.equal(inventoryPage(catalog,999).inventory.page,3);

 result=answer('Покажи SKU-10',state,[]);assert.equal(result.inventory,undefined);assert.equal(result.products[0].id,'SKU-10');
 result=answer('Есть SKU-10?',state,[]);assert.equal(result.inventory,undefined);assert.equal(result.products[0].id,'SKU-10');
 result=answer('Его наличие',state,[]);assert.equal(result.products[0].id,'SKU-10');
 result=answer('Добавь 2 шт SKU-10',state,[]);assert.equal(result.confirm,true);assert.equal(state.pending.qty,2);
 answer('Что есть в наличии?',state,[]);assert.equal(state.pending,null);
 assert.equal(answer('Да, добавь',state,[]).commit,undefined,'inventory lookup cancels an earlier proposal');
 result=answer('Добавь 2 шт SKU-10',state,[]);assert.equal(result.confirm,true);
 assert.equal(answer('Да, добавь',state,[]).commit[0].qty,2,'specific product confirmation still works');

 const live=sale('LIVE-1',5);Object.assign(live,{source:'ekt',isSynthetic:false,purchasable:false,rulesKnown:false,currency:null,unit:null,minOrder:null,step:null});
 catalog.splice(0,catalog.length,live,...excluded);
 result=answer('Что есть в наличии?',state,[]);assert.deepEqual(result.products,[live]);
 assert.match(result.text,/загруженной части каталога EKT API/);assert.match(result.text,/не гарантирует доступность к продаже/);
 assert.ok(purchaseBlockReason(live));assert.equal(answer('Добавь 1 шт LIVE-1',state,[]).confirm,undefined,'positive stock does not bypass incomplete sale data');
 live.stock=null;result=answer('Что есть в наличии?',state,[]);assert.deepEqual(result.products,[]);assert.equal(result.inventory.total,0);assert.equal(result.inventory.pages,0);assert.match(result.text,/не найдено товаров с известным положительным остатком/);assert.doesNotMatch(result.text,/нулевой остаток/);
 live.stock=5;setLanguage('kk');result=answer('Қоймада не бар?',state,[]);assert.deepEqual(result.products,[live]);assert.match(result.text,/EKT API каталогының жүктелген бөлігінде/);setLanguage('ru');
 catalog.splice(0,catalog.length);result=answer('Что есть в наличии?',state,[]);assert.deepEqual(result.products,[]);assert.equal(result.inventory.total,0);

 let calls=0;const unexpectedFetch=async()=>{calls++;throw Error('The inventory route must not call a model');};
 for(const OPENAI_API_KEY of [undefined,'fixture-secret']){
  const interpreted=await understand({text:'Что есть в наличии?',lastId:'LIVE-1'},{OPENAI_API_KEY},unexpectedFetch,[live]);
  assert.deepEqual(interpreted,{canonical:'Что есть в наличии?',mode:'local'});
 }
 assert.equal(calls,0,'inventory works with or without an AI key');
 assert.equal(toCanonical({intent:'clarify',product_ids:[],quantity:null},{text:'Что есть в наличии?'}).canonical,'Что есть в наличии?','model clarification cannot replace inventory lookup');
 assert.equal(toCanonical({intent:'product',product_ids:['LIVE-1'],quantity:null},{text:'Қоймада не бар?',lastId:'LIVE-1'},[live]).canonical,'Қоймада не бар?','model choice cannot replace a broad question with the previous product');
 console.log('PASS: RU/KK inventory requests, finite positive stock, all result pages, stale context, proposal cancellation, explicit purchase confirmation, EKT caveats, empty results and model bypass.');
}finally{catalog.splice(0,catalog.length,...original);setLanguage('ru');}
