import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
import { AppError, DemoCatalog, EktCatalog } from './server/catalog.mjs';
import { Agent, validateAttachment } from './server/agent.mjs';
import { cartView, prepareCart, confirmCart, explicitConfirmation, explicitCancellation } from './server/cart.mjs';

const publicDir = fileURLToPath(new URL('./dist/', import.meta.url));
const token = () => randomBytes(32).toString('hex');
const send = (res,status,data) => { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(data)); };
async function body(req) {
  if (!req.headers['content-type']?.startsWith('application/json')) throw new AppError('Ожидается application/json.', 415);
  const chunks = []; let size = 0;
  for await (const chunk of req) { size += chunk.length; if (size > 7 * 1024 * 1024) throw new AppError('Слишком большой запрос.', 413); chunks.push(chunk); }
  try { const parsed = JSON.parse(Buffer.concat(chunks)); if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw Error(); return parsed; }
  catch { throw new AppError('Некорректный JSON.'); }
}
export function newSession() {
  return { csrf: token(), touched: Date.now(), cart: [], cartVersion: 0, pending: null, receipts: new Map(), history: [], lastProducts: [], busy: false, calls: [] };
}

export function createApp({ catalog = new DemoCatalog(), agent = new Agent(), publicOrigin = process.env.PUBLIC_ORIGIN || '', sessionTTL = 30 * 60 * 1000 } = {}) {
  const sessions = new Map(), limits = new Map();
  function sweep() {
    const now = Date.now();
    for (const [id,s] of sessions) if (!s.busy && now - s.touched > sessionTTL) sessions.delete(id);
    for (const [id,l] of limits) if (now - l.at > 60000) limits.delete(id);
  }
  const timer = setInterval(sweep, 60000).unref();
  const server = http.createServer(async (req,res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; worker-src 'self' blob:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    let session, locked = false;
    try {
      const host = req.headers.host || '', address = server.address();
      const allowedHosts = publicOrigin ? [new URL(publicOrigin).host] : [`127.0.0.1:${address.port}`, `localhost:${address.port}`, `[::1]:${address.port}`];
      if (!allowedHosts.includes(host)) throw new AppError('Недопустимый Host.', 403);
      const url = new URL(req.url, `http://${host}`);
      if (!url.pathname.startsWith('/api/')) {
        if (req.method !== 'GET' && req.method !== 'HEAD') throw new AppError('Метод недоступен.', 405);
        const rel = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
        const target = path.resolve(publicDir, '.' + rel), relative = path.relative(publicDir,target);
        if (relative.startsWith('..') || path.isAbsolute(relative)) throw new AppError('Недоступный путь.', 403);
        const mime = { '.html':'text/html', '.mjs':'text/javascript', '.js':'text/javascript', '.css':'text/css', '.txt':'text/plain', '.svg':'image/svg+xml' }[path.extname(target)];
        if (!mime) throw new AppError('Файл не найден.', 404);
        let bytes; try { bytes = await readFile(target); } catch { throw new AppError('Файл не найден.', 404); }
        res.writeHead(200, { 'Content-Type': `${mime}; charset=utf-8` }); return res.end(req.method === 'HEAD' ? undefined : bytes);
      }
      sweep();
      const ip = req.socket.remoteAddress || 'local', limit = limits.get(ip) || { at: Date.now(), count: 0 };
      if (++limit.count > 150) throw new AppError('Слишком много запросов. Подождите минуту.', 429);
      limits.set(ip,limit);
      if (limits.size > 2000) limits.delete(limits.keys().next().value);
      const id = req.headers.cookie?.split(';').map(x=>x.trim()).find(x=>x.startsWith('ekt_session='))?.slice(12);
      session = sessions.get(id);
      if (!session) {
        if (req.method !== 'GET' || url.pathname !== '/api/session') throw new AppError('Сессия истекла. Обновите страницу.', 401);
        if (sessions.size >= 1000) throw new AppError('Сервер занят. Попробуйте позже.', 503);
        const newId = token(); session = newSession(); sessions.set(newId,session);
        res.setHeader('Set-Cookie', `ekt_session=${newId}; HttpOnly; SameSite=Strict; Path=/${publicOrigin.startsWith('https:') ? '; Secure' : ''}`);
      }
      session.touched = Date.now();
      if (req.method === 'GET') {
        if (url.pathname === '/api/session') return send(res,200,{ csrf: session.csrf, mode: agent.mode, catalogMode: catalog.mode, cart: cartView(session), proposal: session.pending, history: session.history, ttlMinutes: sessionTTL / 60000 });
        if (url.pathname === '/api/cart') return send(res,200,cartView(session));
        throw new AppError('Маршрут не найден.',404);
      }
      if (req.method !== 'POST') throw new AppError('Метод недоступен.',405);
      const expectedOrigin = publicOrigin || `http://${host}`;
      if ((req.headers.origin && req.headers.origin !== expectedOrigin) || req.headers['sec-fetch-site'] === 'cross-site' || req.headers['x-csrf-token'] !== session.csrf) throw new AppError('Запрос не прошёл проверку сессии.',403);
      if (session.busy) throw new AppError('Предыдущий запрос ещё выполняется.',409);
      session.busy = true; locked = true;
      const data = await body(req);
      if (url.pathname === '/api/cart/prepare') {
        if (catalog.mode !== 'demo' && data.source === 'invoice-demo') throw new AppError('Демонстрационная накладная работает только с тестовым каталогом.');
        session.pending = null;
        return send(res,200,{ proposal: await prepareCart(session,catalog,data.items,data.mode || 'add') });
      }
      if (url.pathname === '/api/cart/confirm') return send(res,200,await confirmCart(session,catalog,data.proposalId,data.confirmed));
      if (url.pathname === '/api/cart/cancel') { session.pending = null; return send(res,200,{ cancelled: true }); }
      if (url.pathname === '/api/session/clear') {
        session.history = []; session.lastProducts = []; session.pending = null;
        return send(res,200,{ cleared: true, cart: cartView(session) });
      }
      if (url.pathname !== '/api/chat') throw new AppError('Маршрут не найден.',404);
      const message = typeof data.message === 'string' ? data.message.trim() : '';
      if ((!message && !data.attachment) || message.length > 5000) throw new AppError('Сообщение должно быть от 1 до 5000 символов либо содержать вложение.');
      if (/(?:\d[ -]?){13,19}/.test(message) || /\b(?:cvv|cvc)\s*[:=]?\s*\d{3,4}\b/i.test(message)) throw new AppError('Не отправляйте платёжные реквизиты. Удалите их из сообщения.');
      if (data.attachment) {
        if (data.attachmentConsent !== true) throw new AppError('Подтвердите отправку вложения ИИ-провайдеру.');
        validateAttachment(data.attachment);
      }
      if (!data.attachment && explicitCancellation(message)) {
        session.pending = null; return send(res,200,{ text: 'Подборка отменена. Корзина не изменена.', products: [], proposal: null, mode: agent.mode });
      }
      if (!data.attachment && explicitConfirmation(message)) {
        const result = await confirmCart(session,catalog,data.proposalId,true);
        const text = `Добавлено в корзину прототипа. Сумма ${result.cart.total} ₸. Реальный заказ не оформлен.`;
        session.history.push({role:'user',content:message},{role:'assistant',content:text}); session.history = session.history.slice(-16);
        return send(res,200,{ ...result, text, products: [], proposal: null, mode: agent.mode });
      }
      session.pending = null;
      session.calls = session.calls.filter(t=>Date.now()-t < 60000);
      if (session.calls.length >= 12) throw new AppError('Подождите минуту перед следующим запросом к агенту.',429);
      session.calls.push(Date.now());
      try { return send(res,200,await agent.run(session,catalog,message,data.attachment)); }
      catch (e) { session.pending = null; throw e; }
    } catch (e) {
      if (!res.headersSent) send(res,e instanceof AppError ? e.status : 500,{ error: e instanceof AppError ? e.message : 'Внутренняя ошибка сервера. Повторите запрос.', proposal: session?.pending || null });
    } finally { if (locked && session) session.busy = false; }
  });
  server.requestTimeout = 60000; server.headersTimeout = 15000;
  server.on('close',()=>clearInterval(timer));
  return { server, sessions };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const host = process.env.HOST || '127.0.0.1', port = Number(process.env.PORT || 8080);
  if (!['127.0.0.1','localhost','::1'].includes(host) && (process.env.ALLOW_REMOTE !== 'true' || !process.env.PUBLIC_ORIGIN?.startsWith('https://'))) throw Error('Для внешнего доступа нужны ALLOW_REMOTE=true и PUBLIC_ORIGIN=https://...; настройте авторизацию на reverse proxy.');
  if (!['demo','ekt'].includes(process.env.CATALOG_MODE || 'demo')) throw Error('CATALOG_MODE должен быть demo или ekt.');
  let overrides = {};
  try { overrides = JSON.parse(await readFile(new URL('./data/unit-overrides.json',import.meta.url),'utf8')); } catch(e) { if(e.code !== 'ENOENT') throw e; }
  const catalog = process.env.CATALOG_MODE === 'ekt' ? new EktCatalog({overrides}) : new DemoCatalog();
  const agent = new Agent(), {server} = createApp({catalog,agent});
  server.listen(port,host,()=>console.log(`EKT: http://${host}:${port} | assistant=${agent.mode} | catalog=${catalog.mode}`));
}
