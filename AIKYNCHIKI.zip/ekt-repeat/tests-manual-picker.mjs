import assert from 'node:assert/strict';
import {initializeManualPicker} from './dist/manual-picker.mjs';
import {catalog} from './dist/core.mjs';
import {addDraftProduct} from './dist/purchase-draft.mjs';
import {setLanguage} from './dist/locale.mjs';

// Run the real picker and catalog client with an in-memory DOM and HTTP fixtures.
// No server, credentials or network requests are used.
class Element{
 constructor(tag='div'){this.tagName=tag;this.children=[];this.attributes={};this._text='';this.checked=false;this.value='';this.open=false;this.disabled=false;this.hidden=false;this.className='';}
 set textContent(value){this._text=String(value);this.children=[];}
 get textContent(){return this._text+this.children.map(child=>child.textContent).join('');}
 append(...children){this.children.push(...children);}
 replaceChildren(...children){this._text='';this.children=[...children];}
 setAttribute(key,value){this.attributes[key]=String(value);}
 getAttribute(key){return this.attributes[key]??null;}
 focus(){this.focused=true;}
 showModal(){this.open=true;}
 close(){this.open=false;}
 scrollIntoView(){this.scrolled=true;}
 reportValidity(){
  if(this.value==='')return true;
  const value=Number(this.value),min=Number(this.min||0),step=Number(this.step||1),multiple=(value-min)/step;
  return Number.isFinite(value)&&value>=min&&(this.step==='any'||Math.abs(multiple-Math.round(multiple))<1e-8);
 }
}
const saved={document:globalThis.document,window:globalThis.window,fetch:globalThis.fetch},original=[...catalog];
const elements=new Map(),$=id=>{if(!elements.has(id))elements.set(id,new Element());return elements.get(id);};
globalThis.document={getElementById:$,createElement:tag=>new Element(tag),documentElement:{lang:'ru'}};
globalThis.window=new EventTarget();
const sale=(id,extra={})=>({id,name:'Товар '+id,source:'ekt',isSynthetic:false,currency:'KZT',price:100,unit:'шт',minOrder:1,step:1,rulesKnown:true,purchasable:true,stock:50,warehouses:[],warnings:[],...extra});
const products=[sale('P-1',{name:'Автоматический выключатель 1P C16'}),sale('P-2'),sale('STEP',{minOrder:2,step:3}),...Array.from({length:7},(_,i)=>sale('MORE-'+i)),sale('ZERO',{stock:0}),sale('UNKNOWN',{stock:null,purchasable:false}),sale('LIVE',{unit:null,minOrder:null,step:null,rulesKnown:false,purchasable:false})];
let responseMode='success',rows=[],pageLoaded=false;
const requests=[],snapshot=()=>({source:'ekt',isSynthetic:false,verifiedAt:1,currency:'KZT',products:pageLoaded?[...products,sale('PAGE-3')]:products,coverage:{pages:pageLoaded?[1,2,3]:[1,2],hasMore:!pageLoaded,nextPage:pageLoaded?null:3}});
globalThis.fetch=async(url,options={})=>{
 const address=new URL(url);requests.push({path:address.pathname,query:address.search,method:options.method||'GET'});
 if(address.pathname.endsWith('/api/config'))return {ok:true,json:async()=>({enabled:false,csrf:'fixture-csrf'})};
 assert.ok(address.pathname.endsWith('/api/catalog'),'unexpected external or mutation request: '+address.pathname);
 if(responseMode==='error')return {ok:false,json:async()=>({error:'catalog_unavailable'})};
 if(address.searchParams.get('page')==='3')pageLoaded=true;
 return {ok:true,json:async()=>structuredClone(snapshot())};
};
const descend=(node,predicate)=>predicate(node)?node:node.children.map(child=>descend(child,predicate)).find(Boolean);
const cards=()=>$('manualProducts').children.filter(node=>node.className==='manual-item');
function card(id){const result=cards().find(node=>descend(node,child=>child.className==='line-meta'&&child.textContent===id));assert.ok(result,'missing card '+id);return result;}
const quantity=id=>descend(card(id),node=>node.tagName==='input');
const addButton=id=>descend(card(id),node=>node.tagName==='button');
function input(id,value){quantity(id).value=String(value);quantity(id).oninput();}
function search(value){$('manualSearch').value=value;$('manualSearch').oninput();}
function add(id){assert.equal(addButton(id).disabled,false);addButton(id).onclick();}
try{
 initializeManualPicker({getRows:()=>rows,onAdd:(product,qty)=>{rows=addDraftProduct(rows,product.id,qty);}});
 $('manualInStock').checked=true;
 const initialLoad=$('manualRetry').onclick();
 assert.equal($('manualProducts').getAttribute('aria-busy'),'true');assert.equal($('manualRetry').disabled,true);assert.match($('manualCount').textContent,/Загружаем/);
 await initialLoad;
 assert.equal($('manualProducts').getAttribute('aria-busy'),'false');assert.equal($('manualRetry').disabled,false);assert.equal(cards().length,8);assert.equal($('manualMore').hidden,false);
 assert.match($('manualSource').textContent,/Цены в тенге \(₸\)/);assert.match(card('P-1').textContent,/100 ₸ \/ шт/);assert.doesNotMatch(card('P-1').textContent,/валюта не указана/);
 $('manualStartBtn').onclick();assert.equal($('manualDialog').open,true);

 input('P-1',2);input('P-2',7);add('P-1');
 assert.equal(rows[0].qty,2);assert.equal(quantity('P-1').value,'1','only the successfully added card resets');assert.equal(quantity('P-2').value,'7','adding a different product preserves typed quantity');assert.match($('manualStatus').textContent,/Добавлено/);assert.equal($('manualStatus').className,'subtle');
 search('P-2');assert.equal(quantity('P-2').value,'7');input('P-2','');search('P-1');search('P-2');assert.equal(quantity('P-2').value,'','unfinished input survives search');input('P-2',7);search('');
 $('manualInStock').checked=false;$('manualInStock').onchange();assert.equal(quantity('P-2').value,'7');$('manualInStock').checked=true;$('manualInStock').onchange();assert.equal(quantity('P-2').value,'7');
 $('manualMore').onclick();assert.ok(cards().length>8);assert.equal(quantity('P-2').value,'7');
 search('does-not-exist');assert.equal(cards().length,0);assert.match($('manualProducts').textContent,/Подходящих товаров нет/);search('');assert.equal(quantity('P-2').value,'7');
 setLanguage('kk');search('ажыратқыш');assert.equal(cards().length,1);assert.match(card('P-1').textContent,/Автоматты ажыратқыш/);assert.equal($('manualTitle').textContent,'Каталогтан тауарларды таңдау');search('P-2');assert.equal(quantity('P-2').value,'7');setLanguage('ru');search('');

 input('P-2',1000);add('P-2');assert.equal(rows.length,1);assert.equal($('manualStatus').className,'error');assert.match($('manualStatus').textContent,/превышает остаток/);assert.equal(quantity('P-2').value,'1000','failed addition retains the value for correction');
 input('P-2',7);add('P-2');assert.equal(rows.find(row=>row.product.id==='P-2').qty,7);assert.equal($('manualStatus').className,'subtle');
 assert.equal(quantity('STEP').value,'3');assert.equal(quantity('STEP').min,'3');assert.equal(quantity('STEP').step,'3');assert.equal(quantity('STEP').reportValidity(),true);
 input('STEP',4);assert.equal(quantity('STEP').reportValidity(),false);add('STEP');assert.equal(rows.some(row=>row.product.id==='STEP'),false);input('STEP',6);add('STEP');assert.equal(rows.find(row=>row.product.id==='STEP').qty,6);
 $('manualInStock').checked=false;$('manualInStock').onchange();search('ZERO');assert.equal(addButton('ZERO').disabled,true);
 search('UNKNOWN');add('UNKNOWN');assert.equal(rows.find(row=>row.product.id==='UNKNOWN').selected,false,'unknown availability cannot become a purchase');
 search('LIVE');assert.match(addButton('LIVE').textContent,/для уточнения/);add('LIVE');assert.equal(rows.find(row=>row.product.id==='LIVE').selected,false);assert.match($('manualStatus').textContent,/условия покупки нужно уточнить/);

 search('');$('manualInStock').checked=true;$('manualInStock').onchange();input('P-1',9);input('P-2',13);
 responseMode='error';const failedLoad=$('manualRetry').onclick();
 assert.equal($('manualRetry').disabled,true);assert.equal(addButton('P-1').disabled,true);assert.equal(quantity('P-2').value,'13');await failedLoad;
 assert.equal(cards().length,0);assert.equal($('manualStatus').className,'error');assert.match($('manualStatus').textContent,/Не удалось проверить/);assert.equal($('manualRetry').disabled,false);assert.equal($('manualProducts').getAttribute('aria-busy'),'false');assert.equal(rows.find(row=>row.product.id==='P-2').qty,7);
 responseMode='success';await $('manualRetry').onclick();assert.equal($('manualStatus').textContent,'');assert.equal(quantity('P-1').value,'9');assert.equal(quantity('P-2').value,'13','retry restores typed quantities for recovered products');
 assert.equal($('manualNext').hidden,false);await $('manualNext').onclick();assert.equal($('manualNext').hidden,true);assert.ok(requests.some(request=>request.query==='?page=3'));search('PAGE-3');assert.equal(cards().length,1);search('');assert.equal(quantity('P-2').value,'13');
 $('manualDone').onclick();assert.equal($('manualDialog').open,false);assert.equal($('fileTitle').scrolled,true);$('manualStartBtn').onclick();assert.equal(quantity('P-2').value,'13');
 assert.ok(requests.every(request=>request.method==='GET'&&/\/api\/(?:config|catalog)$/.test(request.path)),'picker may read fixtures only; draft edits must not call purchase endpoints');
 console.log('PASS: independent quantity inputs, search/filter/language redraws, add errors, loading/error/retry, KZT display, minimum/step alignment, blocked drafts and catalog pagination; no network.');
}finally{setLanguage('ru');catalog.splice(0,catalog.length,...original);Object.assign(globalThis,saved);}
