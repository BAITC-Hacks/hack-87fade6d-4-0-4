import assert from 'node:assert/strict';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import os from 'node:os';import path from 'node:path';
import {createStore} from './server/store.mjs';
import {answer,createConsultant} from './dist/consultant.mjs';
import {setLanguage} from './dist/locale.mjs';
import {recommendations} from './dist/recommendations.mjs';
import {catalog,toLines} from './dist/core.mjs';
import {toCanonical} from './server/ai.mjs';
const dir=await mkdtemp(path.join(os.tmpdir(),'ekt-store-test-'));let store=createStore(dir);
try{
 const a=await store.register({email:'a@example.test',password:'demo-password-A'}),b=await store.register({email:'b@example.test',password:'demo-password-B'});
 assert.equal(store.user(a.token).id,a.user.id);assert.equal(store.user('fake'),null);
 const rows=store.db.prepare('SELECT * FROM users').all();assert.ok(rows.every(r=>r.password.length===128&&!r.password.includes('demo-password')));assert.notEqual(rows[0].salt,rows[1].salt);
 await assert.rejects(()=>store.login({email:'a@example.test',password:'wrong-password'}),e=>e.code==='login_failed');
 const saved=store.save(a.user.id,{messages:[{role:'user',text:'D-201 бар ма?',productIds:[]},{role:'assistant',text:'Сынақ каталогының деректері',productIds:['D-201','FAKE']}],lastId:'D-201'});
 assert.equal(store.get(a.user.id,saved.id).lastId,'D-201');assert.deepEqual(store.get(a.user.id,saved.id).messages[1].productIds,['D-201']);assert.equal(store.list(b.user.id).length,0);
 for(const action of [()=>store.get(b.user.id,saved.id),()=>store.save(b.user.id,{id:saved.id,messages:[]}),()=>store.remove(b.user.id,saved.id)])assert.throws(action,e=>e.status===404);
 assert.throws(()=>store.save(a.user.id,{messages:[{role:'user',text:'4111 1111 1111 1111'}]}),e=>e.code==='invalid_history');
 let ticket=store.ticket(a.user.id,{issue:'Нужен инженер для проекта',contact:'@example',includeTranscript:false,messages:[{role:'user',text:'private'}]});assert.deepEqual(ticket.transcript,[]);assert.equal(ticket.status,'prepared');assert.equal(store.tickets(b.user.id).length,0);
 ticket=store.ticket(a.user.id,{issue:'Күрделі жобаға көмек қажет',includeTranscript:true,messages:[{role:'user',text:'D-201'}],language:'kk'});assert.equal(ticket.transcript.length,1);
 store.close();store=createStore(dir);assert.equal(store.get(a.user.id,saved.id).messages.length,2);assert.equal(store.user(a.token).id,a.user.id);store.logout(a.token);assert.equal(store.user(a.token),null);assert.ok((await store.login({email:'a@example.test',password:'demo-password-A'})).token);store.remove(a.user.id,saved.id);assert.equal(store.list(a.user.id).length,0);
 const result=recommendations(['D-201'],[]);assert.deepEqual(result.map(x=>x.product.id),['D-401','D-501']);assert.ok(result.every(x=>x.reason&&x.product.stock>0));assert.deepEqual(recommendations(['D-201'],[{product:catalog.find(p=>p.id==='D-401'),qty:1}]).map(x=>x.product.id),['D-501']);assert.equal(recommendations(['D-101']).length,0);
 setLanguage('kk');const state=createConsultant();let r=answer('D-201 бар ма?',state,[]);assert.match(r.text,/Сынақ/);r=answer('D-101 2 дана қос',state,[]);assert.ok(r.confirm);assert.match(r.text,/Иә, қос/);r=answer('Иә, қос',state,[]);assert.equal(r.commit[0].qty,2);assert.match(r.text,/себетіне/);assert.equal(answer('Иә, қос',state,r.commit).commit,undefined);
 assert.ok(answer('Жүктемені есептеп бер',state,[]).escalate);assert.deepEqual(answer('D-201 ілеспе тауарлар',state,[]).relatedIds,['D-201']);
 assert.equal(toCanonical({intent:'escalate',product_ids:[],quantity:null},{text:'help'}).canonical,'Нужен менеджер');assert.match(toCanonical({intent:'clarify',product_ids:[],quantity:null},{language:'kk',text:'???'}).clarification,/нақтылаңыз/);
 assert.equal(toLines([['Артикул','Атауы','Саны','Өлшем бірлігі','Бағасы'],['D-101','Ажыратқыш','2','дана','1850']])[0].unit,'шт');
 setLanguage('ru');console.log('PASS: salted passwords, login/logout, persistence, account isolation, ticket consent, RU/KK confirmation, recommendations and Kazakh table headers.');
}finally{store.close();if(path.resolve(dir).startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(dir).startsWith('ekt-store-test-'))await rm(dir,{recursive:true,force:true});}
