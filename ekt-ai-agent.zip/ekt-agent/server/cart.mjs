import { randomUUID } from 'node:crypto';
import { AppError, validateItems } from './catalog.mjs';

export const cartView = session => ({ items: session.cart, total: Math.round(session.cart.reduce((n,r) => n + r.qty * r.product.price, 0) * 100) / 100, currency: 'KZT', url: '/#cart', mode: 'prototype', version: session.cartVersion });
const fingerprint = rows => JSON.stringify(rows.map(r => [r.product.id, r.qty, r.product.price, r.product.unit]).sort((a,b) => a[0].localeCompare(b[0])));
export async function prepareCart(session, catalog, items, mode = 'add') {
  if (!['add','replace'].includes(mode)) throw new AppError('Неизвестный режим корзины.');
  if (!Array.isArray(items) || !items.length) throw new AppError('Укажите товары и количество.');
  const previous = mode === 'add' ? session.cart.map(r => ({ id: r.product.id, qty: r.qty })) : [];
  const rows = await validateItems(catalog, [...previous, ...items]);
  const proposal = { id: randomUUID(), mode, items: rows, currency: 'KZT', expiresAt: Date.now() + 300000, baseVersion: session.cartVersion,
    total: Math.round(rows.reduce((n,r) => n + r.qty * r.product.price, 0) * 100) / 100 };
  session.pending = proposal; return proposal;
}
export async function confirmCart(session, catalog, proposalId, confirmed) {
  if (confirmed !== true) throw new AppError('Нужно явное подтверждение пользователя.');
  if (session.receipts.has(proposalId)) return { cart: cartView(session), duplicate: true };
  const p = session.pending;
  if (!p || p.id !== proposalId || p.expiresAt < Date.now() || p.baseVersion !== session.cartVersion) throw new AppError('Подборка устарела. Подготовьте и подтвердите её заново.', 409);
  let fresh;
  try { fresh = await validateItems(catalog, p.items.map(r => ({ id: r.product.id, qty: r.qty }))); }
  catch (e) { session.pending = null; throw e; }
  if (fingerprint(fresh) !== fingerprint(p.items)) { session.pending = null; throw new AppError('Цена или единица изменилась. Нужна новая проверка и подтверждение.', 409); }
  session.cart = fresh; session.cartVersion++; session.pending = null;
  session.receipts.set(proposalId, true);
  if (session.receipts.size > 50) session.receipts.delete(session.receipts.keys().next().value);
  return { cart: cartView(session), duplicate: false };
}
export const explicitConfirmation = s => /^(да,?\s+добавь|подтверждаю|иә,?\s+қос|yes,?\s+add)[.!]?$/i.test(s.trim());
export const explicitCancellation = s => /^(нет|не добавляй|отмена|отмени|жоқ|no|cancel)[.!]?$/i.test(s.trim());
