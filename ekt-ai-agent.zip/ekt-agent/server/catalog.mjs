import { readFile } from 'node:fs/promises';
import https from 'node:https';
import { catalog as original, norm } from '../dist/core.mjs';
import { ektTerms } from './terms.mjs';

export class AppError extends Error {
  constructor(message, status = 400) { super(message); this.status = status; }
}
const number = v => v !== null && v !== '' && v !== undefined && Number.isFinite(Number(v)) ? Number(v) : null;
const clean = v => String(v ?? '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
const round = n => Math.round(n * 100) / 100;
// The partner endpoint was verified with Node's HTTPS transport over IPv4.
// Do not follow redirects with the Basic Auth header, or accept arbitrary tool URLs.
export function fetchEkt(url, options = {}) {
  return new Promise((resolve,reject)=>{
    const request = https.get(url, { headers: options.headers, signal: options.signal, family: 4 }, response=>{
      const chunks=[];let bytes=0;
      response.on('data',chunk=>{bytes+=chunk.length;if(bytes>8*1024*1024)request.destroy(Error('API response too large'));else chunks.push(chunk);});
      response.on('error',reject);
      response.on('end',()=>resolve({ok:response.statusCode>=200&&response.statusCode<300,status:response.statusCode,json:async()=>JSON.parse(Buffer.concat(chunks).toString('utf8'))}));
    });
    request.on('error',reject);
  });
}
export function safeEktUrl(value) {
  try { const u = new URL(value, 'https://ekt.kz'); return u.protocol === 'https:' && u.hostname === 'ekt.kz' && !u.username && !u.password ? u.href : null; } catch { return null; }
}
export class DemoCatalog {
  mode = 'demo';
  constructor() {
    this.products = original.map(p => ({ ...structuredClone(p), sku: p.id, minQty: 1, currency: 'KZT',
      source: 'Синтетический каталог — не предложение EKT', fetchedAt: new Date().toISOString(),
      warehouses: [{ name: 'Демо-склад', stock: p.stock }], warnings: [],
      certificates: p.id === 'D-101' ? [{ title: 'Учебный образец сертификата (недействителен)', url: '/certificates/demo-D-101.html' }] : [] }));
  }
  async get(id) { const p = this.products.find(p => norm(p.id) === norm(id) || norm(p.sku) === norm(id)); if (!p) throw new AppError('Товар не найден.', 404); return structuredClone(p); }
  async search(query) {
    const words = norm(query).split(' ').filter(Boolean);
    return { products: this.products.filter(p => words.every(w => norm(`${p.id} ${p.name} ${p.spec}`).includes(w))).slice(0, 8), scope: 'Полный демонстрационный каталог, 8 товаров.' };
  }
  async alternatives(id) {
    const p = await this.get(id);
    return { products: this.products.filter(x => x.id !== p.id && x.group === p.group && x.stock > 0).map(x => ({ ...x, reason: `Совпадают параметры: ${p.spec}. Отличается серия. Совместимость проверена только в демонстрационной группе.` })), scope: 'Демонстрационная матрица совместимости.' };
  }
  terms() { return { source: 'Учебные условия, не действующие условия EKT', payment: 'В демо: оплата по счёту или картой при оформлении. В чате оплата не принимается.', delivery: 'В демо: самовывоз или доставка; срок и стоимость согласуются с менеджером.', minimum: 'В демо: от 1 шт или 1 м, в пределах остатка.', manager: 'Для реальной покупки уточните условия у менеджера на https://ekt.kz.' }; }
}

const propertyLabels = { KOLICHESTVO_POLYUSOV: 'Полюса', NOMINALNYY_TOK: 'Номинальный ток', NOMINALNOE_NAPRYAZHENIE: 'Напряжение', NOMINALNAYA_OTKLYUCHAYUSHCHAYA_SPOSOBNOST: 'Отключающая способность', TIP_USTANOVKI: 'Монтаж', STEPEN_ZASHCHITY: 'Защита IP', SECHENIE: 'Сечение', KOLICHESTVO_ZHIL: 'Число жил' };
export function normalizeEkt(raw, overrides = {}) {
  if (!raw || !raw.id || typeof raw.name !== 'string') throw new AppError('Неизвестный формат карточки EKT.', 502);
  const props = raw.properties || {}, warnings = [];
  const description = clean(raw.description).slice(0, 5000);
  const titleAmps = raw.name.match(/(?:^|\s)(\d+)\s*[AА](?=\s|$)/i)?.[1];
  const fieldAmps = clean(props.NOMINALNYY_TOK).match(/^(\d+)\s*[AА]$/i)?.[1];
  if (titleAmps && fieldAmps && titleAmps !== fieldAmps) warnings.push(`Расхождение данных EKT: название — ${titleAmps} А, поле номинального тока — ${fieldAmps} А. Уточните у менеджера.`);
  const unitRaw = overrides[String(raw.id)]?.unit || raw.unit || props.EDINICA_IZMERENIYA || props.CML2_BASE_UNIT;
  const unit = /^(шт|шт\.|штука|796)$/i.test(unitRaw) ? 'шт' : /^(м|м\.|метр|006)$/i.test(unitRaw) ? 'м' : null;
  if (!unit) warnings.push('API не сообщил подтверждённую единицу измерения. Добавление в корзину недоступно до уточнения.');
  const certificates = [];
  for (const [key, val] of Object.entries(props)) {
    if (!/cert|sert|сертификат/i.test(key)) continue;
    for (const v of [val].flat()) {
      const url = typeof v === 'string' && /^(https:\/\/|\/upload\/)/.test(v) ? safeEktUrl(v) : null;
      if (url) certificates.push({ title: 'Сертификат из карточки EKT', url });
    }
  }
  return { id: String(raw.id), sku: clean(raw.article || raw.id), name: clean(raw.name), brand: clean(props.TORGOVAYA_MARKA),
    price: number(raw.price), currency: 'KZT', stock: number(raw.quantity), unit, minQty: number(props.KRATNOST_MIN),
    spec: Object.entries(propertyLabels).filter(([key]) => props[key]).map(([key,label]) => `${label}: ${clean(props[key])}`).join(' · '),
    description, category: clean(props.OBYEM), warehouses: (raw.stores || []).map(s => ({ name: clean(s.name), stock: number(s.quantity) })),
    certificates, warnings, url: safeEktUrl(raw.url), source: 'API ekt.kz', fetchedAt: new Date().toISOString() };
}

export class EktCatalog {
  mode = 'ekt';
  constructor({ username = process.env.EKT_USERNAME, password = process.env.EKT_PASSWORD, fetchImpl = fetchEkt,
    maxPages = Number(process.env.EKT_MAX_PAGES || 5), indexPath = new URL('../data/ekt-index.json', import.meta.url), overrides = {} } = {}) {
    this.username = username; this.password = password; this.fetch = fetchImpl;
    this.maxPages = Math.max(1, Math.min(100, maxPages)); this.indexPath = indexPath;
    this.overrides = overrides; this.cache = new Map(); this.index = null; this.indexAt = 0;
  }
  async request(path) {
    if (!this.username || !this.password) throw new AppError('Заполните EKT_USERNAME и EKT_PASSWORD на сервере.', 503);
    let response;
    try { response = await this.fetch(`https://ekt.kz/api/${path}`, { headers: { Authorization: `Basic ${Buffer.from(`${this.username}:${this.password}`).toString('base64')}`, Accept: 'application/json', 'User-Agent': 'EKT-Hackathon-Prototype/1.0' }, redirect: 'error', signal: AbortSignal.timeout(12000) }); }
    catch { throw new AppError('API EKT недоступен или не ответил за 12 секунд. Попробуйте позже.', 502); }
    if (!response.ok) throw new AppError(`API EKT вернул HTTP ${response.status}.`, 502);
    try { return await response.json(); } catch { throw new AppError('API EKT вернул некорректный JSON.', 502); }
  }
  async loadIndex() {
    if (this.index && Date.now() - this.indexAt < 300000) return this.index;
    try {
      const saved = JSON.parse(await readFile(this.indexPath, 'utf8'));
      if (Array.isArray(saved.items) && saved.items.every(x => x.id && typeof x.name === 'string')) {
        this.index = { items: saved.items, scope: `Локальный индекс от ${saved.fetchedAt}; ${saved.complete ? 'полная выгрузка на момент синхронизации' : 'частичная выгрузка'}. Цена и остаток читаются из API отдельно.` };
        this.indexAt = Date.now(); return this.index;
      }
    } catch (e) { if (e.code !== 'ENOENT' && !(e instanceof SyntaxError)) throw e; }
    const items = []; let complete = false;
    for (let page = 1; page <= this.maxPages; page++) {
      const data = await this.request(`products?page=${page}`);
      if (!Array.isArray(data.items)) throw new AppError('Неизвестный формат списка EKT.', 502);
      items.push(...data.items);
      if (!data.items.length || data.items.length < data.per_page) { complete = true; break; }
    }
    this.indexAt = Date.now();
    this.index = { items, scope: complete ? 'Полный индекс API на момент загрузки.' : `Частичный индекс: первые ${this.maxPages} страниц API. Отсутствие в результатах не означает отсутствие в каталоге. Укажите числовой ID карточки или обновите индекс.` };
    return this.index;
  }
  async get(id, { fresh = false } = {}) {
    let productId = String(id);
    if (!/^\d+$/.test(productId)) {
      const { items } = await this.loadIndex();
      const matches = items.filter(p => norm(p.article) === norm(id));
      if (matches.length !== 1) throw new AppError('Артикул не найден однозначно в загруженном индексе. Укажите ID карточки EKT.', 404);
      productId = String(matches[0].id);
    }
    const cached = this.cache.get(productId);
    if (!fresh && cached && Date.now() - cached.at < 30000) return structuredClone(cached.product);
    const product = normalizeEkt(await this.request(`products/detail?id=${encodeURIComponent(productId)}`), this.overrides);
    if (this.cache.size >= 1000) this.cache.delete(this.cache.keys().next().value);
    this.cache.set(productId, { at: Date.now(), product }); return structuredClone(product);
  }
  async search(query) {
    if (/^\d+$/.test(query.trim())) return { products: [await this.get(query.trim())], scope: 'Карточка по числовому ID.' };
    const { items, scope } = await this.loadIndex(), words = norm(query).split(' ').filter(Boolean);
    const matches = items.filter(p => words.every(w => norm(`${p.article} ${p.name}`).includes(w))).slice(0, 6);
    return { products: await Promise.all(matches.map(p => this.get(p.id))), scope };
  }
  async alternatives(id) {
    const p = await this.get(id);
    // RECOMMEND is not a compatibility matrix. Never mistake related items for equivalents.
    return { products: [], scope: `${p.name}: API не предоставляет проверенную матрицу аналогов. Передайте характеристики менеджеру. Автоматическая совместимость не подтверждена.` };
  }
  terms() { return structuredClone(ektTerms); }
}

export async function validateItems(catalog, items, { fresh = true } = {}) {
  if (!Array.isArray(items) || !items.length || items.length > 200) throw new AppError('Укажите от 1 до 200 позиций.');
  const totals = new Map();
  for (const item of items) {
    if (!item || typeof item.id !== 'string' || !Number.isFinite(item.qty) || item.qty <= 0 || item.qty > 1e7) throw new AppError('Проверьте артикул и положительное количество.');
    const total = (totals.get(item.id) || 0) + item.qty;
    if (Math.abs(total * 100 - Math.round(total * 100)) > 1e-6) throw new AppError('Количество: не больше двух знаков после запятой.');
    totals.set(item.id, round(total));
  }
  const result = [], canonical = new Map();
  for (const [id, qty] of totals) {
    const p = await catalog.get(id, { fresh });
    const existing = canonical.get(p.id); canonical.set(p.id, { product: p, qty: round((existing?.qty || 0) + qty) });
  }
  for (const { product: p, qty } of canonical.values()) {
    if (!p.unit || p.stock === null || p.price === null || !Number.isFinite(p.price) || p.price < 0) throw new AppError(`Неполные данные товара ${p.sku}: цена, остаток или единица. Обратитесь к менеджеру.`);
    if (p.warnings.length) throw new AppError(`Товар ${p.sku} требует проверки менеджером: ${p.warnings.join(' ')}`);
    if (p.unit === 'шт' && !Number.isInteger(qty)) throw new AppError('Для штук нужно целое количество.');
    if (p.minQty != null && qty < p.minQty) throw new AppError(`Минимальное количество ${p.sku}: ${p.minQty} ${p.unit}.`);
    if (qty > p.stock) throw new AppError(`Недостаточно остатка ${p.sku}: доступно ${p.stock} ${p.unit}, запрошено ${qty}.`);
    result.push({ product: p, qty });
  }
  return result;
}
