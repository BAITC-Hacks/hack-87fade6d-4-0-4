import {createHash} from 'node:crypto';
import {catalogSeed,catalogMetadata} from '../dist/catalog-data.mjs';
import {ServiceError} from './ai.mjs';

// This provider intentionally has no fallback from live data to demonstration data.
export function catalogSnapshot(){
 if(process.env.CATALOG_SOURCE&&process.env.CATALOG_SOURCE!=='demo')throw new ServiceError('catalog_unavailable',503);
 const data={...structuredClone(catalogMetadata),products:structuredClone(catalogSeed)};
 return {...data,total:data.products.length,verifiedAt:Date.now(),revision:createHash('sha256').update(JSON.stringify(data)).digest('hex')};
}

const status={type:'string',enum:['in_stock','limited_stock','out_of_stock']};
const text={type:'string',minLength:1};
const quantity={type:'number',minimum:0};
export const catalogSchema={
 $schema:'https://json-schema.org/draft/2020-12/schema',
 title:'Жанна AI — синтетический каталог и остатки, версия 1.0',
 description:'Полный снимок демонстрационного каталога. Это не данные магазина EKT. verifiedAt — время выдачи снимка, dataUpdatedAt — время изменения набора. Относительные ссылки документов разрешаются относительно корня приложения, включая BASE_PATH.',
 type:'object',additionalProperties:false,
 required:['schemaVersion','source','isSynthetic','dataUpdatedAt','warehouses','total','verifiedAt','revision','products'],
 properties:{
  schemaVersion:{const:'1.0'},source:{const:'demo'},isSynthetic:{const:true},
  dataUpdatedAt:{type:'string',format:'date-time'},verifiedAt:{type:'integer',minimum:0},
  revision:{type:'string',pattern:'^[a-f0-9]{64}$'},total:{type:'integer',minimum:1},
  warehouses:{type:'array',minItems:1,items:{type:'object',additionalProperties:false,required:['id','name','city'],properties:{id:text,name:text,city:text}}},
  products:{type:'array',minItems:1,items:{$ref:'#/$defs/product'}}
 },
 $defs:{
  certificate:{type:'object',additionalProperties:false,required:['url','label','isSample'],properties:{url:{type:'string',format:'uri-reference'},label:text,isSample:{const:true}}},
  product:{type:'object',additionalProperties:false,
   required:['id','name','category','brand','group','spec','attributes','price','currency','unit','stock','availability','warehouses','minOrder','step','certificate','certificates'],
   properties:{
    id:text,name:text,category:text,brand:text,group:text,spec:text,
    attributes:{type:'array',minItems:1,items:{type:'object',additionalProperties:false,required:['name','value'],properties:{name:text,value:text,unit:text}}},
    price:{type:'number',minimum:0},currency:{const:'KZT'},unit:text,stock:quantity,availability:status,
    warehouses:{type:'array',minItems:1,items:{type:'object',additionalProperties:false,required:['id','name','stock','status'],properties:{id:text,name:text,stock:quantity,status}}},
    minOrder:{type:'number',exclusiveMinimum:0},step:{type:'number',exclusiveMinimum:0},
    certificate:{description:'Совместимое поле прежнего интерфейса. Предпочтительное поле для интеграции — certificates.',anyOf:[{type:'null'},{type:'object',additionalProperties:false,required:['url','label'],properties:{url:{type:'string',format:'uri-reference'},label:text}}]},
    certificates:{type:'array',items:{$ref:'#/$defs/certificate'}}
   }
  }
 }
};

// A full row contains nested fields as JSON so warehouse and attribute structure survives CSV export.
const csvColumns=['id','name','category','brand','spec','attributes','certificates','price','currency','unit','stock','availability','warehouses','minOrder','step','source','isSynthetic','schemaVersion','dataUpdatedAt'];
const csvCell=value=>{
 let text=typeof value==='object'?JSON.stringify(value):String(value??'');
 // Harmless for the fixed synthetic set, and prevents formulas if a later provider supplies labels.
 if(/^[=+@\-\t\r]/.test(text))text="'"+text;
 return '"'+text.replaceAll('"','""')+'"';
};
export function catalogCsv(snapshot){
 const rows=snapshot.products.map(product=>csvColumns.map(key=>csvCell(key in product?product[key]:snapshot[key])).join(';'));
 return '\uFEFF'+[csvColumns.map(csvCell).join(';'),...rows].join('\r\n')+'\r\n';
}
