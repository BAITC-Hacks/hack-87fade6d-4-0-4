import {createHash} from 'node:crypto';
import {ServiceError} from './ai.mjs';

const ORIGIN='https://ekt.kz';
const TTL=60_000;
const MAX_PAGES=10;
const PAGE_SIZE=20;
const MAX_BODY_BYTES=2*1024*1024;
const REQUEST_TIMEOUT=15_000;
const unavailable=()=>new ServiceError('catalog_unavailable',503);
const text=value=>typeof value==='string'?value.trim():typeof value==='number'&&Number.isFinite(value)?String(value):'';
const nonnegative=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0?value:null;
const status=stock=>stock===null?'unknown':stock>0?'in_stock':'out_of_stock';
const record=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const unique=values=>[...new Set(values.filter(Boolean))];
const clone=value=>structuredClone(value);

// The project owner selected tenge for EKT prices. This is application
// configuration, not a currency field supplied by the upstream API, and does
// not convert the numeric price or establish any other terms of sale.
export const EKT_PRICE_CURRENCY='KZT';
const configuredCurrency={currency:EKT_PRICE_CURRENCY,currencyKnown:true,currencySource:'project_config'};

function productId(value){
 const id=text(value);
 return /^[1-9]\d{0,15}$/.test(id)&&Number.isSafeInteger(Number(id))?id:null;
}
function safeHttps(value,{ektOnly=false}={}){
 if(typeof value!=='string'||/[\u0000-\u0020\u007f]/.test(value))return null;
 try{
  const url=new URL(value);
  if(url.protocol!=='https:'||url.username||url.password||(ektOnly&&url.origin!==ORIGIN))return null;
  return url.href;
 }catch{return null;}
}
function propertyValue(value){
 if(record(value))return text(value.value??value.VALUE);
 if(Array.isArray(value))return value.map(text).filter(Boolean).join(', ');
 return text(value);
}

// Only fields with a known technical meaning receive a human-readable label.
// Commerce metadata (CML2_TRAITS, taxes, barcodes, etc.) is not a specification.
const technicalLabels={
 KOLICHESTVO_POLYUSOV:'Количество полюсов',
 NOMINALNAYA_OTKLYUCHAYUSHCHAYA_SPOSOBNOST:'Номинальная отключающая способность',
 NOMINALNOE_NAPRYAZHENIE:'Номинальное напряжение',
 NOMINALNYY_TOK:'Номинальный ток',
 TIP_USTANOVKI:'Тип установки',
 STEPEN_ZASHCHITY:'Степень защиты',
 MATERIAL:'Материал',
 TSVET:'Цвет',
 MOSHCHNOST:'Мощность',
 CHASTOTA:'Частота',
 SECHENIE:'Сечение',
 KOLICHESTVO_ZHIL:'Количество жил'
};
function technicalAttributes(raw,properties){
 const result=[];
 const add=(name,value,unit)=>{
  name=technicalLabels[text(name)]??text(name);value=propertyValue(value);unit=text(unit);
  if(!name||!value||/^[A-Z0-9_]+$/.test(name)||/^(?:CML2_|RECOMMEND$|KRATNOST_MIN$|.*BAR_?CODE$)/i.test(name))return;
  const item={name,value,...(unit?{unit}:{})};
  if(!result.some(existing=>JSON.stringify(existing)===JSON.stringify(item)))result.push(item);
 };
 for(const [key,label] of Object.entries(technicalLabels))add(label,properties[key]);
 const fields=raw.technicalproperties??raw.technicalProperties;
 if(Array.isArray(fields)){
  for(const field of fields)if(record(field))add(field.name??field.NAME,field.value??field.VALUE,field.unit??field.UNIT);
 }else if(record(fields)){
  for(const [key,field] of Object.entries(fields)){
   const name=technicalLabels[key]??(record(field)?field.name??field.NAME??key:key);
   // An unknown machine code has no documented label. Keep it out of the UI.
   if(/^[A-Z0-9_]+$/.test(text(name)))continue;
   add(name,field,record(field)?field.unit??field.UNIT:undefined);
  }
 }
 return result;
}
function amps(value){
 return [...String(value).matchAll(/(?:^|[^\p{L}\d.,])(\d+(?:[.,]\d+)?)\s*[АA](?=$|[^\p{L}\d])/gu)].map(match=>Number(match[1].replace(',','.')));
}
function certificates(raw){
 const fields=Array.isArray(raw.certificates)?raw.certificates:raw.certificate?[raw.certificate]:[];
 const result=[];
 for(const field of fields){
  const url=safeHttps(typeof field==='string'?field:record(field)?field.url:null);
  if(url&&!result.some(item=>item.url===url))result.push({url,label:record(field)?text(field.label??field.name)||'Сертификат':'Сертификат',isSample:false});
 }
 return result;
}

export function normalizeEktProduct(raw,listing={}){
 if(!record(raw))throw unavailable();
 const merged={...listing,...raw};
 const id=productId(merged.id);
 const name=text(merged.name);
 if(!id||!name)throw unavailable();
 const properties=record(raw.properties)?raw.properties:{};
 const article=text(merged.article)||propertyValue(properties.CML2_ARTICLE);
 const supplierArticle=propertyValue(properties.ARTIKULPOSTAVSHCHIKA)||text(merged.supplierArticle);
 const brand=propertyValue(properties.TORGOVAYA_MARKA)||text(merged.brand)||null;
 const technical=technicalAttributes(raw,properties);
 const attributes=[...technical];
 const rawMultiplicity=propertyValue(properties.KRATNOST_MIN);
 if(rawMultiplicity)attributes.push({name:'KRATNOST_MIN',value:rawMultiplicity});
 const stock=nonnegative(raw.quantity);
 const warehouses=[];
 for(const store of Array.isArray(raw.stores)?raw.stores:[]){
  if(!record(store))continue;
  const storeId=text(store.id),storeName=text(store.name);
  if(!storeId||!storeName||warehouses.some(item=>item.id===storeId))continue;
  const quantity=nonnegative(store.quantity);
  warehouses.push({id:storeId,name:storeName,stock:quantity,status:status(quantity)});
 }
 const knownWarehouseStocks=warehouses.map(item=>item.stock).filter(item=>item!==null);
 const warehouseTotal=knownWarehouseStocks.length?knownWarehouseStocks.reduce((sum,item)=>sum+item,0):null;
 const documentLinks=certificates(raw);
 const nameAmps=amps(name);
 const attributeAmps=technical.filter(item=>/номинальн.*ток/i.test(item.name)).flatMap(item=>amps(item.value+(item.unit?' '+item.unit:'')));
 const ampMismatch=nameAmps.length>0&&attributeAmps.some(value=>!nameAmps.includes(value));
 const warnings=[
  'Единица продажи не указана в API.',
  'Минимальная партия и шаг заказа не подтверждены API.',
  'Остатки складов переданы API; возможность отгрузки не подтверждена.'
 ];
 if(stock===null)warnings.push('Общий остаток не указан в API.');
 if(ampMismatch)warnings.push('Противоречие номинального тока: название содержит '+nameAmps.join(', ')+' А, характеристики — '+unique(attributeAmps.map(String)).join(', ')+' А. Требуется проверка менеджером; подбор аналога отключён.');
 return {
  id,article,supplierArticle:supplierArticle||null,aliases:unique([id,article,supplierArticle]),name,
  category:'Не указана в API',categoryKnown:false,brand,unit:null,price:nonnegative(merged.price),
  ...configuredCurrency,stock,warehouseTotal,
  warehouseTotalComplete:warehouses.length>0&&knownWarehouseStocks.length===warehouses.length,
  warehouses,warehouseStockMeaning:'raw_api_stock',warehouseFulfillmentKnown:false,availability:status(stock),
  minOrder:null,step:null,rulesKnown:false,purchasable:false,group:null,
  spec:technical.map(item=>item.name+': '+item.value+(item.unit?' '+item.unit:'')).join(' · '),attributes,
  certificates:documentLinks,certificate:documentLinks.length?{url:documentLinks[0].url,label:documentLinks[0].label}:null,
  relatedIds:unique((Array.isArray(properties.RECOMMEND)?properties.RECOMMEND:[]).map(productId)),
  analogEligible:!ampMismatch&&technical.length>0,source:'ekt',isSynthetic:false,
  externalUrl:safeHttps(merged.url,{ektOnly:true}),image:safeHttps(merged.image,{ektOnly:true}),
  sourceUpdatedAt:null,warnings
 };
}

function revisionOf(data){return createHash('sha256').update(JSON.stringify(data)).digest('hex');}
function buildSnapshot(pages,verifiedAt){
 const ordered=[...pages.entries()].sort(([a],[b])=>a-b);
 const products=[...new Map(ordered.flatMap(([,page])=>page.products).map(product=>[product.id,product])).values()];
 const warehouses=[...new Map(products.flatMap(product=>product.warehouses).map(warehouse=>[warehouse.id,{id:warehouse.id,name:warehouse.name,city:null}])).values()];
 const [lastPage,last]=ordered.at(-1);
 const hasMore=last.itemCount===PAGE_SIZE;
 const coverage={pages:ordered.map(([page])=>page),fullCatalog:false,hasMore,nextPage:hasMore&&lastPage<10000&&ordered.length<MAX_PAGES?lastPage+1:null};
 const data={schemaVersion:'1.1',source:'ekt',isSynthetic:false,dataUpdatedAt:null,warehouses,products,total:products.length,coverage,...configuredCurrency};
 return {...data,verifiedAt,revision:revisionOf(data)};
}

export function createEktClient({env=process.env,fetchImpl=fetch,now=Date.now}={}){
 let pages=new Map(),details=new Map(),cached=null,failed=false,queue=Promise.resolve();
 const fresh=at=>now()-at>=0&&now()-at<TTL;
 const allFresh=()=>pages.size>0&&[...pages.values()].every(page=>fresh(page.fetchedAt));
 const serial=operation=>{
  const result=queue.then(operation,operation);
  queue=result.catch(()=>{});
  return result;
 };
 function authentication(){
  const username=env.EKT_API_USERNAME,password=env.EKT_API_PASSWORD;
  if(typeof username!=='string'||!username||username.includes(':')||typeof password!=='string'||!password)throw unavailable();
  return 'Basic '+Buffer.from(username+':'+password,'utf8').toString('base64');
 }
 async function request(path){
  const authorization=authentication();
  const url=ORIGIN+path;
  const controller=new AbortController();
  let timer;
  const deadline=new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(unavailable());},REQUEST_TIMEOUT);});
  try{
   return await Promise.race([deadline,(async()=>{
    const response=await fetchImpl(url,{method:'GET',headers:{Accept:'application/json',Authorization:authorization},redirect:'error',signal:controller.signal});
    if(!response?.ok||response.redirected||(response.url&&response.url!==url))throw unavailable();
    const declaredLength=response.headers?.get?.('content-length');
    if(declaredLength!==null&&declaredLength!==undefined&&Number(declaredLength)>MAX_BODY_BYTES)throw unavailable();
    let body;
    if(response.body?.getReader){
     const reader=response.body.getReader();
     const chunks=[];let bytes=0;
     try{
      while(true){
       const {done,value}=await reader.read();if(done)break;
       bytes+=value.byteLength;
       if(bytes>MAX_BODY_BYTES){controller.abort();void reader.cancel().catch(()=>{});throw unavailable();}
       chunks.push(Buffer.from(value));
      }
     }finally{reader.releaseLock();}
     body=Buffer.concat(chunks).toString('utf8');
    }else if(typeof response.text==='function'){
     body=await response.text();
     if(Buffer.byteLength(body,'utf8')>MAX_BODY_BYTES)throw unavailable();
    }else throw unavailable();
    return JSON.parse(body);
   })()]);
  }catch{throw unavailable();}finally{clearTimeout(timer);}
 }
 async function fetchDetail(id,listing={}){
  const raw=await request('/api/products/detail?id='+encodeURIComponent(id));
  if(productId(raw?.id)!==id)throw unavailable();
  return normalizeEktProduct(raw,listing);
 }
 async function fetchPage(page){
  const raw=await request('/api/products?page='+page);
  if(!record(raw)||!Array.isArray(raw.items)||raw.items.length>PAGE_SIZE||(raw.page!==undefined&&raw.page!==page)||(raw.per_page!==undefined&&raw.per_page!==PAGE_SIZE))throw unavailable();
  const seen=new Set();
  const items=raw.items.filter(item=>{
   const id=record(item)?productId(item.id):null;
   if(!id||!text(item.name))throw unavailable();
   if(seen.has(id))return false;seen.add(id);return true;
  });
  return {items,itemCount:raw.items.length};
 }
 async function concurrentMap(values,action){
  const result=new Array(values.length);let cursor=0,failure;
  await Promise.all(Array.from({length:Math.min(4,values.length)},async()=>{
   while(!failure&&cursor<values.length){
    const index=cursor++;
    try{result[index]=await action(values[index]);}catch(error){failure=error;}
   }
  }));
  if(failure)throw failure;
  return result;
 }
 function validatePage(page){
  if(!Number.isInteger(page)||page<1||page>10000)throw new ServiceError('invalid_catalog_page',400);
 }
 async function load({page,force=false}={}){
  if(page!==undefined)validatePage(page);
  return serial(async()=>{
   const requested=page===undefined?(pages.size?[...pages.keys()]:[1,2]):[page];
   const targetPages=unique([...pages.keys(),...requested]).sort((a,b)=>a-b);
   if(targetPages.length>MAX_PAGES)throw new ServiceError('catalog_page_limit',400);
   // A failed request must be revalidated; it never returns a stale substitute.
   const toFetch=targetPages.filter(number=>force||failed||!pages.has(number)||!fresh(pages.get(number).fetchedAt));
   if(!toFetch.length&&cached)return clone(cached);
   try{
    const fetched=[];
    for(const number of toFetch)fetched.push([number,await fetchPage(number)]);
    const uniqueItems=[...new Map(fetched.flatMap(([,data])=>data.items).map(item=>[String(item.id),item])).values()];
    const products=await concurrentMap(uniqueItems,item=>fetchDetail(String(item.id),item));
    const byId=new Map(products.map(product=>[product.id,product]));
    const nextPages=new Map([...pages].map(([number,data])=>[number,{...data,products:data.products.map(product=>byId.get(product.id)||product)}])),at=now();
    for(const [number,data] of fetched)nextPages.set(number,{products:data.items.map(item=>byId.get(String(item.id))),itemCount:data.itemCount,fetchedAt:at});
    const nextSnapshot=buildSnapshot(nextPages,at);
    const nextDetails=new Map(details);
    for(const product of products)nextDetails.set(product.id,{product,fetchedAt:at});
    pages=nextPages;details=nextDetails;cached=nextSnapshot;failed=false;
    return clone(cached);
   }catch{failed=true;throw unavailable();}
  });
 }
 async function detail(value,{force=false}={}){
  const id=productId(value);
  if(!id)throw new ServiceError('invalid_catalog_id',400);
  return serial(async()=>{
   const found=details.get(id);
   if(!force&&!failed&&found&&fresh(found.fetchedAt))return clone(found.product);
   try{
    const listing=cached?.products.find(product=>product.id===id);
    const product=await fetchDetail(id,listing?{id:listing.id,name:listing.name,article:listing.article,price:listing.price,url:listing.externalUrl,image:listing.image}:{});
    details.set(id,{product,fetchedAt:now()});
    // One detail response does not extend the freshness of any complete page.
    if(cached&&pages.size){
     const nextPages=new Map([...pages].map(([number,data])=>[number,{...data,products:data.products.map(item=>item.id===id?product:item)}]));
     cached=buildSnapshot(nextPages,cached.verifiedAt);pages=nextPages;
    }
    return clone(product);
   }catch{failed=true;throw unavailable();}
  });
 }
 function snapshot(){
  if(!cached||failed||!allFresh())throw unavailable();
  return clone(cached);
 }
 return {load,detail,snapshot};
}
