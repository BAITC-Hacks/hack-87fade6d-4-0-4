import {DatabaseSync} from 'node:sqlite';
import {mkdirSync} from 'node:fs';
import path from 'node:path';
import {randomBytes,randomUUID,createHash,scrypt as scryptCallback,timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {ServiceError,sensitive} from './ai.mjs';
import {catalog} from '../dist/core.mjs';
const scrypt=promisify(scryptCallback);
const hash=s=>createHash('sha256').update(s).digest('hex');
const fail=(code,status=400)=>{throw new ServiceError(code,status);};
const publicUser=u=>u?{id:u.id,email:u.email}:null;
// Historical references confer no purchase authority; resolve against current catalog when used.
const knownId=id=>typeof id==='string'&&(catalog.some(p=>p.id===id)||/^[1-9][0-9]{0,15}$/.test(id)&&Number.isSafeInteger(Number(id)))&&!sensitive(id);
export function createStore(directory){
 mkdirSync(directory,{recursive:true});
 const db=new DatabaseSync(path.join(directory,'app.sqlite'));
 db.exec(`PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;
 CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,salt TEXT NOT NULL,password TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS conversations(id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),title TEXT NOT NULL,messages TEXT NOT NULL,last_id TEXT,updated INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS tickets(id TEXT PRIMARY KEY,user_id TEXT REFERENCES users(id),issue TEXT NOT NULL,contact TEXT NOT NULL,transcript TEXT NOT NULL,language TEXT NOT NULL,created INTEGER NOT NULL);
 `);
 const purge=()=>{db.prepare('DELETE FROM conversations WHERE updated<?').run(Date.now()-30*86400000);db.prepare('DELETE FROM tickets WHERE created<?').run(Date.now()-30*86400000);};purge();
 const session=uid=>{const token=randomBytes(32).toString('hex');db.prepare('DELETE FROM sessions WHERE expires < ?').run(Date.now());db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(token),uid,Date.now()+7*86400000);return token;};
 const credentials=input=>{const email=String(input?.email||'').trim().toLowerCase(),password=input?.password;if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||sensitive(email)||typeof password!=='string'||password.length<10||password.length>128)fail('invalid_credentials');return {email,password};};
 const owner=(uid,id)=>{const row=db.prepare('SELECT * FROM conversations WHERE id=? AND user_id=?').get(id,uid);if(!row)fail('not_found',404);return row;};
 const cleanMessages=messages=>{
  if(!Array.isArray(messages)||messages.length>200)fail('history_limit');
  return messages.map(m=>{if(!m||!['user','assistant'].includes(m.role)||typeof m.text!=='string'||m.text.length>7000||sensitive(m.text))fail('invalid_history');return {role:m.role,text:m.text,productIds:Array.isArray(m.productIds)?m.productIds.filter(knownId).slice(0,8):[]};});
 };
 return {
  db,
  async register(input){const {email,password}=credentials(input);const salt=randomBytes(16).toString('hex'),digest=await scrypt(password,salt,64);const user={id:randomUUID(),email};try{db.prepare('INSERT INTO users VALUES(?,?,?,?)').run(user.id,email,salt,digest.toString('hex'));}catch(e){if(e.code?.startsWith('ERR_SQLITE'))fail('account_unavailable',409);throw e;}return {user,token:session(user.id)};},
  async login(input){const {email,password}=credentials(input),row=db.prepare('SELECT * FROM users WHERE email=?').get(email);const digest=await scrypt(password,row?.salt||'00000000000000000000000000000000',64);if(!row||!timingSafeEqual(digest,Buffer.from(row.password,'hex')))fail('login_failed',401);return {user:publicUser(row),token:session(row.id)};},
  user(token){if(!token)return null;return publicUser(db.prepare('SELECT users.* FROM sessions JOIN users ON sessions.user_id=users.id WHERE token=? AND expires>?').get(hash(token),Date.now()));},
  logout(token){if(token)db.prepare('DELETE FROM sessions WHERE token=?').run(hash(token));},
  list(uid){purge();return db.prepare('SELECT id,title,updated FROM conversations WHERE user_id=? ORDER BY updated DESC LIMIT 100').all(uid);},
  get(uid,id){purge();const row=owner(uid,id);return {id:row.id,title:row.title,messages:JSON.parse(row.messages),lastId:row.last_id};},
  save(uid,input){purge();const messages=cleanMessages(input.messages);const lastId=knownId(input.lastId)?input.lastId:null;const title=(messages.find(m=>m.role==='user')?.text||'Жанна AI').slice(0,80);const id=input.id||randomUUID();if(input.id)owner(uid,id);else if(db.prepare('SELECT COUNT(*) AS n FROM conversations WHERE user_id=?').get(uid).n>=100)fail('conversation_limit');db.prepare('INSERT INTO conversations VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,messages=excluded.messages,last_id=excluded.last_id,updated=excluded.updated').run(id,uid,title,JSON.stringify(messages),lastId,Date.now());return {id};},
  remove(uid,id){owner(uid,id);db.prepare('DELETE FROM conversations WHERE id=? AND user_id=?').run(id,uid);return {ok:true};},
  ticket(uid,input){const issue=String(input.issue||'').trim(),contact=String(input.contact||'').trim();if(issue.length<5||issue.length>1200||contact.length>150||sensitive(issue)||sensitive(contact))fail('invalid_ticket');const transcript=input.includeTranscript===true?cleanMessages(input.messages||[]).slice(-8):[];const id='EKT-'+randomBytes(5).toString('hex').toUpperCase(),language=input.language==='kk'?'kk':'ru';db.prepare('INSERT INTO tickets VALUES(?,?,?,?,?,?,?)').run(id,uid||null,issue,contact,JSON.stringify(transcript),language,Date.now());return {id,issue,contact,transcript,language,status:'prepared',manager:'iconofyourlife'};},
  tickets(uid){purge();return db.prepare('SELECT id,issue,contact,transcript,language,created FROM tickets WHERE user_id=? ORDER BY created DESC LIMIT 30').all(uid).map(t=>({...t,transcript:JSON.parse(t.transcript),status:'prepared',manager:'iconofyourlife'}));},
  eraseHistory(uid){db.exec('BEGIN');try{db.prepare('DELETE FROM conversations WHERE user_id=?').run(uid);db.prepare('DELETE FROM tickets WHERE user_id=?').run(uid);db.exec('COMMIT');return {ok:true};}catch(e){db.exec('ROLLBACK');throw e;}},
  close(){db.close();}
 };
}
