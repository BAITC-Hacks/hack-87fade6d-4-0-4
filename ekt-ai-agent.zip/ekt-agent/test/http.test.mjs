import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { createApp } from '../server.mjs';
import { Agent } from '../server/agent.mjs';
import { DemoCatalog } from '../server/catalog.mjs';
async function setup(t,options={}){
  const {server}=createApp({agent:new Agent({apiKey:''}),...options});await new Promise(r=>server.listen(0,'127.0.0.1',r));
  t.after(()=>new Promise(r=>{server.close(r);server.closeAllConnections();}));
  const url=`http://127.0.0.1:${server.address().port}`;
  async function client(){const res=await fetch(url+'/api/session');const cookie=res.headers.get('set-cookie').split(';')[0],s=await res.json();
    return {s,cookie,async request(path,data,extra={}){const r=await fetch(url+path,{method:data===undefined?'GET':'POST',headers:{Cookie:cookie,'Content-Type':'application/json','X-CSRF-Token':s.csrf,...extra},...(data===undefined?{}:{body:JSON.stringify(data)})});return {status:r.status,body:await r.json()};}};
  }return {url,client};
}
test('HTTP happy path, reload persistence, direct cart link, no action on negative confirmation',async t=>{
  const {client}=await setup(t),c=await client();
  let r=await c.request('/api/chat',{message:'Добавь D-101 2 шт'});assert.equal(r.status,200);const id=r.body.proposal.id;
  assert.equal((await c.request('/api/cart')).body.items.length,0);
  r=await c.request('/api/chat',{message:'не добавляй',proposalId:id});assert.equal(r.status,200);
  assert.equal((await c.request('/api/cart/confirm',{proposalId:id,confirmed:true})).status,409);
  r=await c.request('/api/chat',{message:'Добавь D-101 2 шт'});
  const confirmed=await c.request('/api/chat',{message:'да, добавь',proposalId:r.body.proposal.id});assert.equal(confirmed.body.cart.items[0].qty,2);
  assert.equal((await c.request('/api/session')).body.cart.items[0].qty,2);
});
test('CSRF, foreign origin, second session and secret/static paths are protected',async t=>{
  const {url,client}=await setup(t),c=await client(),other=await client();
  assert.equal((await c.request('/api/chat',{message:'D-101'},{'X-CSRF-Token':'wrong'})).status,403);
  assert.equal((await c.request('/api/chat',{message:'D-101'},{Origin:'https://attacker.invalid'})).status,403);
  const p=(await c.request('/api/cart/prepare',{items:[{id:'D-101',qty:2}]})).body.proposal;
  assert.equal((await other.request('/api/cart/confirm',{proposalId:p.id,confirmed:true})).status,409);
  for(const path of ['/.env','/server.mjs','/package.json'])assert.equal((await fetch(url+path)).status,404);
  const status=await new Promise((resolve,reject)=>{const r=http.get(url+'/',{headers:{Host:'attacker.invalid'}},res=>{res.resume();resolve(res.statusCode);});r.on('error',reject);});
  assert.equal(status,403);
});
test('bad attachment consent, oversized message and payment data are rejected',async t=>{
  const {client}=await setup(t),c=await client();
  for(const data of [{message:'x'.repeat(5001)},{message:'карта 4242 4242 4242 4242'},{message:'file',attachment:{name:'x.pdf',data:'bad'},attachmentConsent:false}])assert.equal((await c.request('/api/chat',data)).status,400);
  assert.equal((await c.request('/api/cart/prepare',{})).status,400);
});
test('server serializes session mutations and leaves state intact on concurrent request',async t=>{
  let release;const gate=new Promise(r=>release=r),catalog=new DemoCatalog();
  const agent={mode:'demo',async run(){await gate;return {text:'ready'};}};
  const {client}=await setup(t,{agent,catalog}),c=await client();
  const first=c.request('/api/chat',{message:'wait'});await new Promise(r=>setTimeout(r,50));
  assert.equal((await c.request('/api/cart/prepare',{items:[{id:'D-101',qty:1}]})).status,409);
  release();assert.equal((await first).status,200);
});
