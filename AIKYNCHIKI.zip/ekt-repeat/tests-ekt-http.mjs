import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {parseDelimited} from './dist/core.mjs';
const cwd=path.dirname(fileURLToPath(import.meta.url)),directory=await mkdtemp(path.join(os.tmpdir(),'ekt-live-http-'));
const origin='http://127.0.0.1:8086',base=origin+'/zhanna/';
const child=spawn(process.execPath,['--import','./tests-fixtures/ekt-fetch.mjs','server.mjs'],{cwd,env:{...process.env,PORT:'8086',PUBLIC_ORIGIN:origin,BASE_PATH:'/zhanna/',EKT_DATA_DIR:directory,CATALOG_SOURCE:'ekt',EKT_API_USERNAME:'fixture-user',EKT_API_PASSWORD:'fixture-password',EKT_TEST_FIXTURES:'1',OPENAI_API_KEY:'fixture-openai'},stdio:['ignore','pipe','pipe'],windowsHide:true});
let csrf='',cookie='',user='guest';
async function call(route,method='GET',data){const response=await fetch(base+'api/'+route,{method,headers:{Origin:origin,'Content-Type':'application/json','X-EKT-Token':csrf,'X-EKT-User':user,Cookie:cookie},...(data===undefined?{}:{body:JSON.stringify(data)})});const raw=await response.text();assert.ok(!raw.includes('fixture-password'));assert.ok(!raw.includes('fixture-openai'));return {status:response.status,body:JSON.parse(raw),headers:response.headers};}
try{
 await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Test server startup timed out')),10000);child.stdout.once('data',()=>{clearTimeout(timer);resolve();});child.once('exit',code=>{clearTimeout(timer);reject(Error('Server exited '+code));});child.once('error',reject);});
 const config=await call('config');csrf=config.body.csrf;assert.equal(config.body.catalogSource,'ekt');
 const catalog=await call('catalog');assert.equal(catalog.status,200);assert.equal(catalog.body.source,'ekt');assert.equal(catalog.body.isSynthetic,false);assert.equal(catalog.body.total,2);
 const product=catalog.body.products.find(p=>p.id==='515291');assert.equal(product.article,'200300285_');assert.equal(product.price,64920);assert.equal(product.currency,'KZT');assert.equal(product.currencyKnown,true);assert.equal(product.currencySource,'project_config');assert.equal(product.unit,null);assert.equal(product.stock,23);assert.equal(product.purchasable,false);assert.ok(product.warnings.some(w=>w.includes('160')&&w.includes('250')));
 assert.equal(catalog.body.currency,'KZT');assert.equal(catalog.body.currencySource,'project_config');
 const detail=await call('catalog/detail?id=515291');assert.equal(detail.body.id,'515291');assert.equal(detail.body.currency,'KZT');assert.equal(detail.body.currencySource,'project_config');
 assert.equal((await call('catalog?page=3')).body.total,3);assert.equal((await call('catalog?page=0')).status,400);
 const schema=(await call('catalog/schema')).body;assert.equal(schema.properties.source.const,'ekt');assert.equal(schema.properties.currency.const,'KZT');assert.equal(schema.properties.currencySource.const,'project_config');assert.equal(schema.properties.products.items.properties.currency.const,'KZT');assert.ok(schema.properties.products.items.required.includes('currencySource'));
 const exported=await fetch(base+'api/catalog/export?format=json');assert.match(exported.headers.get('content-disposition'),/attachment/);const json=await exported.json();assert.equal(json.source,'ekt');assert.equal(json.currency,'KZT');assert.ok(json.products.every(p=>p.currency==='KZT'&&p.currencyKnown===true&&p.currencySource==='project_config'));
 const csv=await fetch(base+'api/catalog/export?format=csv');const csvText=await csv.text();assert.match(csvText,/"ekt"/);assert.match(csvText,/"null"/);assert.ok(!csvText.includes('fixture-password'));
 const rows=parseDelimited(csvText),columns=rows.shift(),value=(row,key)=>row[columns.indexOf(key)];assert.ok(rows.length>0);assert.ok(rows.every(row=>value(row,'currency')==='KZT'&&value(row,'currencySource')==='project_config'));const exportedProduct=rows.find(row=>value(row,'id')==='515291');assert.equal(value(exportedProduct,'price'),'64920');assert.equal(value(exportedProduct,'unit'),'null');assert.equal(value(exportedProduct,'minOrder'),'null');assert.equal(value(exportedProduct,'step'),'null');assert.equal(value(exportedProduct,'purchasable'),'false');
 for(const privatePath of ['.env.ekt.local','.env.local','server/ekt-client.mjs','.data/app.sqlite'])assert.equal((await fetch(base+privatePath)).status,404);
 const cart=await call('cart');cookie=cart.headers.get('set-cookie').split(';')[0];
 const blocked=await call('cart/proposals','POST',{mode:'add',version:0,items:[{id:'515291',qty:1,unit:'шт'}]});assert.equal(blocked.status,409);assert.equal(blocked.body.error,'purchase_data_incomplete');assert.equal((await call('cart')).body.items.length,0);
 assert.equal((await call('understand','POST',{text:'Есть 200300285_?',aiConsent:true})).body.canonical,'Покажи 515291');
 const registration=await call('register','POST',{email:'live-fixture@example.test',password:'a-test-password-123'});assert.equal(registration.status,200);cookie=registration.headers.get('set-cookie').split(';')[0];user=registration.body.user.id;
 const saved=await call('conversations','POST',{messages:[{role:'assistant',text:'Проверка каталога EKT',productIds:['515291','FAKE']}],lastId:'515291'});assert.equal(saved.status,200);
 const history=await call('conversations/'+saved.body.id);assert.equal(history.body.lastId,'515291');assert.deepEqual(history.body.messages[0].productIds,['515291']);
 console.log('PASS EKT HTTP (mock upstream): live metadata, page/detail/export/schema, secret isolation, incomplete purchase blocked, live model IDs and saved history.');
}finally{
 if(child.exitCode===null)await new Promise(resolve=>{child.once('exit',resolve);child.kill();});
 if(path.resolve(directory).startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(directory).startsWith('ekt-live-http-'))await rm(directory,{recursive:true,force:true});
}
