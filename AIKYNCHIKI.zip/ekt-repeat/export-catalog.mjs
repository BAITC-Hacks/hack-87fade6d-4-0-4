import {mkdir,writeFile} from 'node:fs/promises';
import {catalogSnapshot,catalogCsv,catalogSchema} from './server/catalog.mjs';

const directory=new URL('./data/',import.meta.url),snapshot=catalogSnapshot();
await mkdir(directory,{recursive:true});
await Promise.all([
 writeFile(new URL('catalog-sample.json',directory),JSON.stringify(snapshot,null,2)+'\n','utf8'),
 writeFile(new URL('catalog-sample.csv',directory),catalogCsv(snapshot),'utf8'),
 writeFile(new URL('catalog.schema.json',directory),JSON.stringify(catalogSchema,null,2)+'\n','utf8')
]);
console.log(`Exported ${snapshot.total} synthetic products and JSON Schema to data/.`);
